/*! DeckWright runtime v0.3.4 (.hdek) | MIT License | https://github.com/grotyx/deckwright
 *  Present any HTML deck like PowerPoint: steps, presenter view, ink, blackout, print.
 *  Put this file inside an HTML deck as <script data-hdek-runtime> and it just works.
 */
(function () {
  'use strict';
  if ((window.DeckWright && window.DeckWright.__runtime) || (window.HDeck && window.HDeck.__runtime)) return;

  var PRODUCT = 'DeckWright';
  var VERSION = '0.3.4';
  var api = window.DeckWright = window.HDeck = window.DeckWright || window.HDeck || {};
  var ROLE = /^hdek-preview/.test(window.name || '') ? 'preview' : 'audience';

  // UI language: data-hdek-lang="ko|en" > ?hdek-lang= > browser language
  var LANG = (function () {
    try {
      var a = document.documentElement.getAttribute('data-hdek-lang');
      var q = /[?&]hdek-lang=(ko|en)\b/.exec(location.search);
      var v = a || (q && q[1]) || ((navigator.language || '').toLowerCase().indexOf('ko') === 0 ? 'ko' : 'en');
      return v === 'ko' ? 'ko' : 'en';
    } catch (e) { return 'en'; }
  })();
  function T(ko, en) { return LANG === 'ko' ? ko : en; }

  // ------------------------------------------------------------------ utils
  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function store(key, val) {
    try {
      if (val === undefined) return window.localStorage.getItem(key);
      window.localStorage.setItem(key, val);
    } catch (e) { return null; }
  }
  function fmtTime(sec) {
    sec = Math.max(0, Math.floor(sec));
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    var mm = (h ? String(m).padStart(2, '0') : String(m)), ss = String(s).padStart(2, '0');
    return (h ? h + ':' : '') + mm + ':' + ss;
  }
  function textOf(el) {
    if (!el) return '';
    var t = el.textContent || '';
    if (el.querySelector && el.querySelector('br')) { var c = el.cloneNode(true); Array.prototype.forEach.call(c.querySelectorAll('br'), function (br) { br.replaceWith(' '); }); t = c.textContent || ''; }
    return t.replace(/\s+/g, ' ').trim();
  }
  function topLevel(els) {
    return els.filter(function (el) {
      return !els.some(function (o) { return o !== el && o.contains(el); });
    });
  }
  function isTyping(t) {
    if (!t || !t.closest) return false;
    return !!t.closest('input, textarea, select, [contenteditable=""], [contenteditable="true"]');
  }

  // ------------------------------------------------------------------ CSS
  var CSS = [
    'html.hdek-on:not(.hdek-printing):not(.hdek-own) .hdek-slide:not(.hdek-current){display:none!important}',
    'html.hdek-autostage, html.hdek-autostage body{overflow:hidden!important}',
    '.hdek-backdrop{position:fixed;inset:0;background:#000;z-index:2147481000}',
    'html.hdek-autostage:not(.hdek-printing) .hdek-slide.hdek-current{box-sizing:border-box!important;position:fixed!important;left:0!important;top:0!important;right:auto!important;bottom:auto!important;margin:0!important;transform-origin:0 0!important;zoom:1!important;z-index:2147481500!important;box-shadow:none!important;max-width:none!important;max-height:none!important}',
    'html.hdek-on aside.notes, html.hdek-on [data-notes], html.hdek-on .hdek-notes-src, html.hdek-on .speaker-notes{display:none!important}',
    'html.hdek-staged, html.hdek-staged body{margin:0!important;padding:0!important;width:100%;height:100%;overflow:hidden!important;background:#000}',
    '.hdek-stage{position:fixed!important;left:0;top:0;transform-origin:0 0;overflow:hidden}',
    ':where(.hdek-stage) > :where(.hdek-slide){position:absolute;inset:0;box-sizing:border-box}',
    ':where(html.hdek-on) :where(.hdek-step){transition:opacity .45s ease, transform .55s cubic-bezier(.2,.7,.2,1), filter .45s ease}',
    ':where(html.hdek-on) :where(.hdek-step:not(.is-on)){opacity:0;pointer-events:none}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="rise"]:not(.is-on)){transform:translateY(28px)}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="drop"]:not(.is-on)){transform:translateY(-28px)}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="left"]:not(.is-on)){transform:translateX(-48px)}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="right"]:not(.is-on)){transform:translateX(48px)}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="zoom"]:not(.is-on)){transform:scale(.9)}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="blur"]:not(.is-on)){filter:blur(10px)}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="none"]){transition:none}',
    ':where(html.hdek-on) :where(.hdek-step[data-effect="dim"]:not(.is-on)){opacity:.25;pointer-events:auto}',
    ':where(html.hdek-on) :where(.hdek-step.hdek-step-out){opacity:0;pointer-events:none}',
    'html.hdek-snap .hdek-current, html.hdek-snap .hdek-current *{transition:none!important}',
    'html.hdek-preview, html.hdek-preview *{cursor:none!important;caret-color:transparent}',
    'html.hdek-preview body{pointer-events:none!important}',
    'html.hdek-idle, html.hdek-idle *{cursor:none!important}',
    // ink + UI
    '.hdek-ink{position:absolute;left:0;top:0;width:100%;height:100%;z-index:2147483000;pointer-events:none;touch-action:none}',
    '.hdek-ink.hdek-fixed{position:fixed}',
    '.hdek-ink.hdek-active{pointer-events:auto;cursor:crosshair}',
    '.hdek-blank{position:fixed;inset:0;z-index:2147483200;display:none}',
    '.hdek-blank.hdek-blank-on{display:block}',
    '.hdek-ui-host{position:fixed;inset:0;z-index:2147483300;pointer-events:none}',
    '.hdek-ink.hdek-active.hdek-zoomtool{cursor:zoom-in}',
    'html.hdek-zoomed, html.hdek-zoomed body{overflow:hidden!important}',
    '@media print{.hdek-ui,.hdek-ui-host,.hdek-blank{display:none!important}}'
  ].join('\n');

  // Slide overview (grid of thumbnails + search), shared by the audience window and the presenter view
  var GRID_CSS = [
    '.hdg{position:fixed;inset:0;z-index:20;display:flex;flex-direction:column;background:#0c0c0f;color:#ececf0;font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI","Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",sans-serif;pointer-events:auto;cursor:default}',
    '.hdg *{box-sizing:border-box}',
    '.hdg-top{display:flex;align-items:center;gap:12px;padding:14px 18px;border-bottom:1px solid #24242b}',
    '.hdg-q{flex:1;max-width:560px;height:38px;padding:0 14px;border-radius:9px;border:1px solid #3a3a44;background:#1b1b21;color:#fff;font:inherit;font-size:16px;outline:none}',
    '.hdg-q:focus{border-color:#0a84ff}',
    '.hdg-n{color:#9a9aa5;font-variant-numeric:tabular-nums}',
    '.hdg-sp{flex:1}',
    '.hdg-x{all:unset;cursor:pointer;padding:8px 12px;border-radius:8px;background:#24242c;color:#ddd}',
    '.hdg-x:hover{background:#2e2e37}',
    '.hdg-cards{flex:1;overflow:auto;padding:18px;display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:16px;align-content:start}',
    '.hdg-card{cursor:pointer;border-radius:10px;padding:8px;background:#16161b;border:2px solid transparent}',
    '.hdg-card:hover{background:#1e1e25}',
    '.hdg-card.sel{border-color:#0a84ff}',
    '.hdg-card.now .hdg-cap b{background:#30d158;color:#000}',
    '.hdg-th{position:relative;overflow:hidden;border-radius:6px;background:#000}',
    '.hdg-th iframe{position:absolute;left:0;top:0;border:0;transform-origin:0 0;pointer-events:none;background:#000;visibility:hidden}',
    '.hdg-th iframe.on{visibility:visible}',
    '.hdg-ph{position:absolute;inset:0;display:grid;place-items:center;padding:10px;color:#6c6c76;font-size:13px;text-align:center;overflow:hidden}',
    '.hdg-cap{display:flex;gap:8px;align-items:baseline;margin-top:7px;white-space:nowrap;overflow:hidden}',
    '.hdg-cap b{flex:none;min-width:24px;padding:0 6px;border-radius:5px;background:#2a2a33;text-align:center;font-variant-numeric:tabular-nums;font-size:12px}',
    '.hdg-cap span{overflow:hidden;text-overflow:ellipsis}',
    '.hdg-snip{margin-top:4px;color:#a0a0aa;font-size:12px;line-height:1.35;max-height:2.7em;overflow:hidden}',
    '.hdg-snip:empty{display:none}',
    '.hdg-snip mark{background:#ffd60a;color:#000;border-radius:2px;padding:0 1px}',
    '.hdg-none{grid-column:1/-1;color:#888;padding:40px;text-align:center}'
  ].join('\n');

  // Toolbar, toast, help and go-to box live in a shadow root, so a deck's CSS (td, kbd, .card, .on …) cannot reach them
  var UI_CSS = [
    ':host{all:initial}',
    '.hdek-ui{position:fixed;z-index:1;font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI","Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",sans-serif;color:#fff;box-sizing:border-box}',
    '.hdek-ui *{box-sizing:border-box}',
    '.hdek-bar{left:16px;bottom:16px;display:flex;gap:4px;align-items:center;padding:6px;border-radius:12px;background:rgba(20,20,24,.82);backdrop-filter:blur(8px);box-shadow:0 6px 24px rgba(0,0,0,.35);opacity:0;transform:translateY(8px);transition:opacity .25s, transform .25s;pointer-events:none}',
    '.hdek-bar.show{opacity:1;transform:none;pointer-events:auto}',
    '.hdek-bar button{all:unset;box-sizing:border-box;width:34px;height:34px;border-radius:8px;display:grid;place-items:center;cursor:pointer;color:#e8e8ea}',
    '.hdek-bar button:hover{background:rgba(255,255,255,.12)}',
    '.hdek-bar button.on{background:#0a84ff;color:#fff}',
    '.hdek-bar button svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}',
    '.hdek-bar .sep{width:1px;height:22px;background:rgba(255,255,255,.18);margin:0 4px}',
    '.hdek-bar .hdek-sw{width:16px;height:16px;border-radius:50%;border:2px solid rgba(255,255,255,.55)}',
    '.hdek-bar button.hdek-swb.on{background:rgba(255,255,255,.18)}',
    '.hdek-bar .hdek-num{min-width:52px;text-align:center;font-variant-numeric:tabular-nums;color:#c9c9cf;font-size:13px}',
    '.hdek-toast{left:50%;bottom:28px;transform:translateX(-50%);padding:10px 16px;border-radius:10px;background:rgba(20,20,24,.92);max-width:80vw;opacity:0;transition:opacity .25s;pointer-events:none}',
    '.hdek-toast.show{opacity:1}',
    '.hdek-goto{right:24px;bottom:24px;padding:8px 14px;border-radius:10px;background:rgba(20,20,24,.92);font-size:20px;display:none}',
    '.hdek-help{inset:0;background:rgba(0,0,0,.72);display:none;place-items:center;pointer-events:auto}',
    '.hdek-help.on{display:grid}',
    '.hdek-help .hdek-card{background:#18181c;border-radius:16px;padding:24px 28px;min-width:420px;max-width:86vw;box-shadow:0 20px 60px rgba(0,0,0,.5)}',
    '.hdek-help h3{margin:0 0 12px;font-size:17px}',
    '.hdek-help table{border-collapse:collapse;font-size:14px}',
    '.hdek-help td{padding:4px 18px 4px 0;vertical-align:top}',
    '.hdek-help kbd{display:inline-block;padding:1px 7px;margin:1px 2px;border-radius:5px;background:#2c2c32;border:1px solid #3a3a42;font:12px ui-monospace,Menlo,Consolas,monospace;color:#fff}',
    '.hdek-help td{color:#fff}',
    '.hdek-zband{position:fixed;display:none;border:2px solid #0a84ff;background:rgba(10,132,255,.14);border-radius:3px;pointer-events:none}'
  ].join('\n') + '\n' + GRID_CSS;

  function injectCSS(doc, css, id) {
    var s = doc.createElement('style');
    if (id) s.id = id;
    s.textContent = css;
    (doc.head || doc.documentElement).appendChild(s);
    return s;
  }

  // ------------------------------------------------------------------ icons
  var ICON = {
    prev: '<path d="M15 18l-6-6 6-6"/>',
    next: '<path d="M9 18l6-6-6-6"/>',
    pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
    hl: '<path d="M9 11l-6 6v3h9l3-3"/><path d="M22 12l-4.6 4.6a2 2 0 01-2.8 0l-5.2-5.2a2 2 0 010-2.8L14 4"/>',
    laser: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
    eraser: '<path d="M7 21h10"/><path d="M5.5 14.5l7-7a2 2 0 012.8 0l3.2 3.2a2 2 0 010 2.8L13 19H8.5l-3-3a1.1 1.1 0 010-1.5z"/>',
    clear: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/>',
    blank: '<rect x="3" y="5" width="18" height="14" rx="2" fill="currentColor"/>',
    presenter: '<rect x="2" y="4" width="13" height="10" rx="1.5"/><path d="M18 8h4M18 12h4M18 16h4M6 20h5M8.5 14v6"/>',
    full: '<path d="M8 3H5a2 2 0 00-2 2v3M21 8V5a2 2 0 00-2-2h-3M3 16v3a2 2 0 002 2h3M16 21h3a2 2 0 002-2v-3"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 015 .5c0 1.7-2.5 2-2.5 3.5"/><path d="M12 17h.01"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    zoom: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M10.5 7.5v6M7.5 10.5h6"/>',
    grid: '<rect x="3" y="3" width="7.5" height="7.5" rx="1.2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.2"/>',
    play: '<path d="M7 4.5l12 7.5-12 7.5z" fill="currentColor"/>',
    pause: '<path d="M7 4.5h3.5v15H7zM13.5 4.5H17v15h-3.5z" fill="currentColor"/>',
    vol: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor"/><path d="M15.5 9a4 4 0 010 6M18 6.5a7.5 7.5 0 010 11"/>',
    mute: '<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z" fill="currentColor"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>'
  };
  function svg(name) { return '<svg viewBox="0 0 24 24">' + ICON[name] + '</svg>'; }

  var COLORS = ['#ff3b30', '#ffd60a', '#0a84ff', '#30d158', '#ffffff', '#111111'];

  // ------------------------------------------------------------------ state
  var D = {
    mode: 'contract',        // contract | heuristic | reveal | single
    staged: false,
    width: 1920, height: 1080,
    root: null,
    title: document.title || PRODUCT,
    slides: [],              // {el,id,title,notesHTML,steps:[{el,at,out}],max,hook,autoplay}
    state: { slide: 0, step: 0 },
    blank: null,
    tool: null,              // pen | hl | laser | eraser
    color: COLORS[0],
    ink: {},                 // slideId -> [stroke]
    clickAdvance: true,
    wheelAdvance: true,
    duration: 0,
    presenter: null,
    adapter: null,
    listeners: [],
    ready: false
  };
  var pendingHooks = {};

  // ------------------------------------------------------------------ detection
  var HEURISTIC_SELECTORS = [
    'section.slide', '.slide', '.scene', '.slides > section', '.stage > section', '.deck > section', '.deck > .page',
    'main > section', 'body > section', 'article.slide', '.page.slide', '.swiper-slide'
  ];

  // If all slides share one fixed size that differs from the viewport, scale the current slide to fit
  function fixedSize(els) {
    var sample = els.slice(0, 6), w = 0, h = 0;
    for (var i = 0; i < sample.length; i++) {
      var cs = getComputedStyle(sample[i]);
      var sw = parseFloat(cs.width), sh = parseFloat(cs.height);
      if (cs.boxSizing !== 'border-box') {
        // Fit by outer size (padding and border included) so it lands exactly on screen
        sw += (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0) + (parseFloat(cs.borderLeftWidth) || 0) + (parseFloat(cs.borderRightWidth) || 0);
        sh += (parseFloat(cs.paddingTop) || 0) + (parseFloat(cs.paddingBottom) || 0) + (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
      }
      if (!(sw >= 320 && sh >= 180)) return null;
      if (i === 0) { w = sw; h = sh; }
      else if (Math.abs(sw - w) > 1 || Math.abs(sh - h) > 1) return null;
    }
    // Slides sized in vw/vh/% follow the window; scaling them as fixed boxes would scale them twice
    var a = authoredSize(els[0]);
    if (/vw|vh|%|vmin|vmax|calc|dvh|svh|lvh/.test(a.w + a.h)) return null;
    if (Math.abs(w - window.innerWidth) <= 2 && Math.abs(h - window.innerHeight) <= 2 && (!a.w || /auto/.test(a.w + a.h))) return null;
    var ratio = w / h;
    if (ratio < 1 || ratio > 2.5) return null;
    return { w: Math.round(w), h: Math.round(h) };
  }

  function authoredSize(el) {
    var w = el.style.width || '', h = el.style.height || '';
    try {
      Array.prototype.forEach.call(document.styleSheets, function (sh) {
        var rules; try { rules = sh.cssRules; } catch (e) { return; }
        Array.prototype.forEach.call(rules || [], function (r) {
          if (!r.selectorText || !r.style) return;
          var m = false; try { m = el.matches(r.selectorText); } catch (e) { }
          if (!m) return;
          if (r.style.width && !el.style.width) w = r.style.width;
          if (r.style.height && !el.style.height) h = r.style.height;
        });
      });
    } catch (e) { }
    return { w: w, h: h };
  }

  // ------------------------------------------------------------------ driver: decks with their own navigation engine
  // When the deck handles keyboard navigation and step animation itself, leave its engine in charge and steer it with key events.
  var KEYCODES = { ArrowRight: 39, ArrowLeft: 37, ArrowDown: 40, ArrowUp: 38, Home: 36, End: 35, PageDown: 34, PageUp: 33, ' ': 32, Enter: 13 };
  var Driver = {
    activeClass: null,
    maxes: [],
    observer: null,
    syncing: false,
    detect: function (els) {
      if (els.length < 2) return null;
      var code = $$('script:not([src]):not([data-hdek-runtime])').map(function (s) { return s.textContent || ''; }).join('\n');
      if (!/ArrowRight|keyCode\s*===?\s*39|which\s*===?\s*39/.test(code)) return null;
      var names = ['active', 'current', 'cur', 'present', 'is-active', 'show', 'visible', 'on', 'selected'];
      var found = null;
      for (var i = 0; i < names.length && !found; i++) {
        var n = names[i], c = 0;
        els.forEach(function (e) { if (e.classList.contains(n)) c++; });
        if (c === 1) found = n;
      }
      if (!found) return null;
      // If there are hidden step elements the deck's scripts never touch (e.g. an engine unaware of .fragment), take over
      var kinds = [['[data-s]', /data-s\b|dataset\.s\b/], ['[data-step]', /data-step|dataset\.step/], ['.fragment', /fragment/], ['.step', /['".]step\b/]];
      for (var k = 0; k < kinds.length; k++) {
        var hidden = els.some(function (e) { return $$(kinds[k][0], e).some(isHiddenNow); });
        if (hidden && !kinds[k][1].test(code)) return null;
      }
      return found;
    },
    init: function () {
      var self = this;
      this.maxes = D.slides.map(function (s) { return self.stepsOf(s.el).reduce(function (m, e, i) { return Math.max(m, self.rank(e, i)); }, 0); });
      D.slides.forEach(function (s, i) { s.max = self.maxes[i]; });
      var host = D.slides[0].el.parentElement || document.body;
      try {
        this.observer = new MutationObserver(function () {
          if (self.syncing || self.paused) return;
          self.syncing = true;
          requestAnimationFrame(function () { self.syncing = false; self.sync(); });
        });
        this.observer.observe(host, { attributes: true, attributeFilter: ['class'], subtree: true });
      } catch (e) { }
      // The slide's untransformed size is the stage size
      var el = D.slides[0].el;
      if (el.offsetWidth >= 320 && el.offsetHeight >= 180) { D.width = el.offsetWidth; D.height = el.offsetHeight; }
      D.state = this.read();
    },
    stepsOf: function (el) { return $$('[data-s], [data-step], .fragment', el); },
    rank: function (e, i) {
      var v = e.getAttribute('data-s');
      if (v === null) v = e.getAttribute('data-step');
      if (v === null && e.hasAttribute('data-fragment-index')) v = String(+e.getAttribute('data-fragment-index') + 1);
      var n = parseInt(v, 10);
      return n >= 0 ? n : i + 1;
    },
    isOn: function (e) { var c = e.classList; return c.contains('on') || c.contains('is-on') || c.contains('visible') || c.contains('shown') || c.contains('revealed'); },
    read: function () {
      var idx = -1, ac = this.activeClass;
      for (var i = 0; i < D.slides.length; i++) { if (D.slides[i].el.classList.contains(ac)) { idx = i; break; } }
      if (idx < 0) return { slide: D.state.slide < 0 ? 0 : D.state.slide, step: D.state.step };
      var self = this, step = 0;
      this.stepsOf(D.slides[idx].el).forEach(function (e, i) { if (self.isOn(e)) step = Math.max(step, self.rank(e, i)); });
      return { slide: idx, step: step };
    },
    sync: function () {
      if (this.paused) return;
      var s = this.read();
      D.slides.forEach(function (x, i) { x.el.classList.toggle('hdek-current', i === s.slide); });
      if (s.slide !== D.state.slide || s.step !== D.state.step) { D.state = s; afterChange(true); }
      else { fit(); renderInk(); }
    },
    key: function (k) {
      var target = document.body || document.documentElement;
      ['keydown', 'keyup'].forEach(function (type) {
        var ev;
        try { ev = new KeyboardEvent(type, { key: k, code: k === ' ' ? 'Space' : k, bubbles: true, cancelable: true }); } catch (e) { return; }
        try {
          Object.defineProperty(ev, 'keyCode', { get: function () { return KEYCODES[k] || 0; } });
          Object.defineProperty(ev, 'which', { get: function () { return KEYCODES[k] || 0; } });
        } catch (e) { }
        ev.__hdek = true;
        target.dispatchEvent(ev);
      });
    },
    count: function () { return D.slides.length; },
    max: function (i) { return this.maxes[i] || 0; },
    next: function () { this.key('ArrowRight'); this.sync(); },
    prev: function () { this.key('ArrowLeft'); this.sync(); },
    apply: function (prev, target, animate) {
      var cur = this.read(), guard = 0, c;
      var mx = this.max(cur.slide);
      if (cur.slide === target.slide && target.step === cur.step) { /* already there */ }
      else if (animate && cur.slide === target.slide && target.step === cur.step + 1) this.key('ArrowRight');
      else if (animate && target.slide === cur.slide + 1 && target.step === 0 && cur.step >= mx) this.key('ArrowRight');
      else if (cur.slide === target.slide && target.step === cur.step - 1) this.key('ArrowLeft');
      else {
        var done = false;
        if (typeof window.__show === 'function') {
          // Use the deck's own "go to final state of slide n" function if it has one
          try { window.__show(target.slide + 1); } catch (e) { }
          c = this.read();
          while (c.slide === target.slide && c.step > target.step && guard++ < 200) { this.key('ArrowLeft'); c = this.read(); }
          done = c.slide === target.slide && c.step === target.step;
        }
        if (!done) { this.jump(target, animate); return; }
      }
      var now = this.read();
      if (!animate && D.slides[now.slide]) finishAnimations(D.slides[now.slide].el);
      D.state = now;
    },
    // Walk to the target one key at a time. Many decks ignore keys while a transition runs,
    // so when a key changes nothing we wait for the deck before trying again instead of giving up.
    token: 0,
    jump: function (target, animate) {
      var self = this, token = ++this.token, misses = 0, usedHome = false, t0 = Date.now();
      function cmp(a) { return (a.slide - target.slide) || (a.step - target.step); }
      function finish() {
        if (token !== self.token) return;
        var now = self.read();
        if (!animate && D.slides[now.slide]) finishAnimations(D.slides[now.slide].el);
        if (now.slide !== D.state.slide || now.step !== D.state.step) { D.state = now; afterChange(true); }
      }
      function walk() {
        if (token !== self.token) return;
        for (var guard = 0; guard < 400; guard++) {
          var c = self.read(), d = cmp(c);
          if (d === 0 || Date.now() - t0 > 20000) { finish(); return; }
          // far behind the start: one Home is cheaper than many ←
          var k = d < 0 ? 'ArrowRight' : (!usedHome && target.slide < c.slide / 2 ? 'Home' : 'ArrowLeft');
          if (k === 'Home') usedHome = true;
          self.key(k);
          var n = self.read();
          if (n.slide === c.slide && n.step === c.step) { waitFor(c); return; }
          misses = 0;
        }
        setTimeout(walk, 0);
      }
      function waitFor(before) {
        var started = Date.now();
        (function poll() {
          if (token !== self.token) return;
          var n = self.read();
          if (n.slide !== before.slide || n.step !== before.step) { misses = 0; setTimeout(walk, 30); return; }
          if (Date.now() - started < 700) { setTimeout(poll, 25); return; }
          if (++misses >= 3) { finish(); return; } // the deck will not move further
          walk();
        })();
      }
      D.state = this.read();
      walk();
    }
  };

  function collectNotesMap() {
    var map = {};
    var j = document.getElementById('hdek-notes');
    if (j) { try { map = JSON.parse(j.textContent || '{}'); } catch (e) { } }
    return map;
  }

  var NOTES_SEL = 'aside.notes, aside.note, [data-notes], .notes, .speaker-notes';
  function guessTitle(el, i) {
    var h = el.querySelector('h1, h2, h3');
    var t = textOf(h);
    if (!t) {
      var cands = $$('[class*="title"], [class*="head"] h4, h4, [class*="chip"], [class*="kicker"], [class*="eyebrow"], strong, b', el);
      for (var k = 0; k < cands.length && !t; k++) {
        if (cands[k].closest(NOTES_SEL)) continue;
        var s = textOf(cands[k]);
        if (s && s.length >= 2 && s.length <= 90) t = s;
      }
    }
    if (!t) {
      // Without a heading, take the shortest line with the largest font as the title
      var best = null, bestSize = 0, n = 0;
      $$('p, span, div, td, li', el).some(function (c) {
        if (c.closest(NOTES_SEL) || c.children.length > 3) return false;
        var s = textOf(c);
        if (!s || s.length < 2 || s.length > 90) return false;
        if (++n > 60) return true;
        var fs = parseFloat(getComputedStyle(c).fontSize) || 0;
        if (fs > bestSize + 0.5) { bestSize = fs; best = s; }
        return false;
      });
      t = best;
    }
    return t || (T('슬라이드 ', 'Slide ') + (i + 1));
  }

  function isHiddenNow(s) {
    try {
      var cs = getComputedStyle(s);
      return cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) < 0.1;
    } catch (e) { return false; }
  }

  function buildSlide(el, i, notesMap, heuristic) {
    var id = el.getAttribute('data-slide') || el.id || ('s' + (i + 1));
    var title = el.getAttribute('data-title') || guessTitle(el, i);
    if (title.length > 80) title = title.slice(0, 78) + '…';
    var notesEl = el.querySelector(heuristic ? NOTES_SEL : 'aside.notes, [data-notes]');
    if (!notesEl && heuristic) {
      // Notes placed right after a slide (<section class="slide">…</section><aside class="notes">…)
      var sib = el.nextElementSibling;
      if (sib && sib.matches && sib.matches(NOTES_SEL) && !sib.matches('section.slide, .slide, .scene')) notesEl = sib;
    }
    if (notesEl && heuristic && D.mode !== 'driver') notesEl.classList.add('hdek-notes-src');
    var notesHTML = notesEl ? notesEl.innerHTML.trim() : '';
    if (!notesHTML && notesMap[id]) notesHTML = String(notesMap[id]).replace(/[&<>]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]; });
    var sel = heuristic ? '[data-step], .step, .fragment, .reveal-step' : '[data-step]';
    var stepEls = D.mode === 'driver' ? [] : $$(sel, el).filter(function (s) {
      var owner = s.parentElement && s.parentElement.closest('.hdek-slide');
      if (!(owner === el || !owner)) return false;
      // Heuristic: .step/.fragment visible from the start is decoration, not a step
      if (heuristic && !s.hasAttribute('data-step') && !isHiddenNow(s)) return false;
      return true;
    });
    var counter = 0, steps = [];
    stepEls.forEach(function (s) {
      var raw = s.getAttribute('data-step');
      if (raw === null && s.hasAttribute('data-fragment-index')) raw = String(+s.getAttribute('data-fragment-index') + 1);
      var n = parseInt(raw, 10);
      if (!(n > 0)) n = counter + 1;
      counter = Math.max(counter, n);
      var out = parseInt(s.getAttribute('data-step-out'), 10);
      s.classList.add('hdek-step');
      steps.push({ el: s, at: n, out: out > 0 ? out : 0 });
      if (out > counter) counter = out;
    });
    var declared = parseInt(el.getAttribute('data-steps'), 10) || 0;
    var slide = {
      el: el, id: id, title: title, notesHTML: notesHTML, steps: steps,
      max: Math.max(counter, declared), hook: null,
      autoplay: parseInt(el.getAttribute('data-autoplay'), 10) || 0
    };
    el.classList.add('hdek-slide');
    el.setAttribute('data-hdek-index', i + 1);
    return slide;
  }

  function detect() {
    var notesMap = collectNotesMap();
    var root = $('[data-hdek]');
    var els = $$('[data-slide]');
    var heuristic = false;
    if (!els.length && root) els = Array.prototype.slice.call(root.children).filter(function (c) { return c.tagName === 'SECTION'; });
    if (!els.length) {
      heuristic = true;
      for (var i = 0; i < HEURISTIC_SELECTORS.length; i++) {
        var cand = topLevel($$(HEURISTIC_SELECTORS[i])).filter(function (e) { return !e.closest('aside.notes'); });
        if (cand.length >= 2) { els = cand; break; }
      }
    }
    els = topLevel(els);
    if (!els.length) { D.mode = 'single'; els = [document.body]; heuristic = true; }
    else D.mode = heuristic ? 'heuristic' : 'contract';
    if (D.mode === 'heuristic' && ROLE !== 'printonly') {
      var ac = Driver.detect(els);
      if (ac) { D.mode = 'driver'; Driver.activeClass = ac; }
    }
    D.root = root || (els[0] !== document.body ? els[0].parentElement : null);
    D.slides = els.map(function (el, i) { return buildSlide(el, i, notesMap, heuristic); });
    var r = D.root || document.documentElement;
    D.width = parseInt(r.getAttribute('data-width'), 10) || 1920;
    D.height = parseInt(r.getAttribute('data-height'), 10) || 1080;
    D.staged = !!(root && root.getAttribute('data-fit') !== 'none' && D.mode === 'contract');
    if (D.mode === 'driver') Driver.init();
    else if (D.mode === 'heuristic') {
      var sz = fixedSize(els);
      if (sz) { D.autostage = true; D.width = sz.w; D.height = sz.h; }
    }
    D.title = r.getAttribute('data-title') || document.title || PRODUCT;
    D.clickAdvance = r.getAttribute('data-click') !== 'off';
    D.wheelAdvance = r.getAttribute('data-wheel') !== 'off';
    D.duration = parseFloat(r.getAttribute('data-duration')) || 0;
    // hooks registered early
    var early = window.hdekHooks || {};
    Object.keys(early).forEach(function (k) { pendingHooks[k] = early[k]; });
    D.slides.forEach(function (s) { attachHook(s, pendingHooks[s.id]); });
  }

  function attachHook(slide, hook) {
    if (!slide || !hook) return;
    slide.hook = hook;
    slide.max = Math.max(slide.max, parseInt(hook.steps, 10) || 0);
  }

  // ------------------------------------------------------------------ native adapter
  var Native = {
    count: function () { return D.slides.length; },
    max: function (i) { return D.slides[i] ? D.slides[i].max : 0; },
    apply: function (prev, next, animate) {
      var s = D.slides[next.slide];
      if (!s) return;
      var changed = prev.slide !== next.slide;
      if (!animate) document.documentElement.classList.add('hdek-snap');
      if (changed) {
        var old = D.slides[prev.slide];
        if (old) {
          old.el.classList.remove('hdek-current', 'active', 'is-active', 'current', 'present');
          emit(old.el, 'hdek:leave', { index: prev.slide });
          pauseMedia(old.el);
        }
        s.el.classList.add('hdek-current', 'active', 'is-active', 'current', 'present');
        if (D.mode !== 'single') window.scrollTo(0, 0);
      }
      setSteps(s, next.step, animate);
      if (changed) emit(s.el, 'hdek:enter', { index: next.slide, step: next.step, animate: animate });
      if (!animate) {
        void s.el.offsetWidth;
        finishAnimations(s.el);
        requestAnimationFrame(function () { document.documentElement.classList.remove('hdek-snap'); });
      }
    }
  };

  var STEP_ON = ['is-on', 'visible', 'on', 'show', 'shown'];
  function setSteps(s, step, animate) {
    var check = [];
    s.steps.forEach(function (it) {
      var on = step >= it.at;
      var out = it.out && step >= it.out;
      (D.mode === 'heuristic' ? STEP_ON : STEP_ON.slice(0, 2)).forEach(function (c) { it.el.classList.toggle(c, on && !out); });
      it.el.classList.toggle('hdek-step-out', !!out);
      it.el.classList.toggle('current-step', on && !out && it.at === step);
      if (D.mode === 'heuristic') {
        if (on && !out) check.push(it.el);
        else if (it.el.hasAttribute('data-hdek-forced')) { it.el.removeAttribute('data-hdek-forced'); it.el.style.removeProperty('opacity'); it.el.style.removeProperty('visibility'); }
      }
    });
    // In auto-detect mode the deck's own CSS decides what "shown" looks like. If a revealed step is still
    // invisible once its transition has had time to run, show it anyway rather than click through a blank step.
    if (check.length) setTimeout(function () {
      check.forEach(function (el) {
        if (!el.classList.contains('is-on')) return;
        var cs = getComputedStyle(el);
        if (parseFloat(cs.opacity) < 0.05 || cs.visibility === 'hidden') {
          el.setAttribute('data-hdek-forced', '');
          el.style.setProperty('opacity', '1', 'important'); el.style.setProperty('visibility', 'visible', 'important');
        }
      });
    }, animate ? 900 : 30);
    if (s.hook && typeof s.hook.setStep === 'function') {
      try { s.hook.setStep(step, { animate: animate, slide: s.el, max: s.max }); } catch (e) { console.warn('[hdek] hook error', e); }
    }
    emit(s.el, 'hdek:step', { step: step, max: s.max, animate: animate });
  }

  function finishAnimations(el) {
    if (!el.getAnimations) return;
    try {
      el.getAnimations({ subtree: true }).forEach(function (a) {
        try {
          var t = a.effect && a.effect.getComputedTiming ? a.effect.getComputedTiming() : null;
          if (t && isFinite(t.endTime)) a.finish();
        } catch (e) { }
      });
    } catch (e) { }
  }

  function pauseMedia(el) {
    $$('video, audio', el).forEach(function (m) { try { if (!m.hasAttribute('data-keep-playing')) m.pause(); } catch (e) { } });
  }

  function emit(el, type, detail) {
    try { el.dispatchEvent(new CustomEvent(type, { detail: detail, bubbles: true })); } catch (e) { }
  }

  // ------------------------------------------------------------------ reveal.js adapter (experimental)
  var RevealAdapter = {
    list: [],
    init: function () {
      var R = window.Reveal;
      this.list = R.getSlides();
      D.slides = this.list.map(function (el, i) {
        var frags = $$('.fragment', el), idx = {};
        frags.forEach(function (f) { idx[f.getAttribute('data-fragment-index') || ('auto' + Math.random())] = 1; });
        var h = el.querySelector('h1,h2,h3');
        var notes = R.getSlideNotes ? (R.getSlideNotes(el) || '') : '';
        if (!notes) { var a = el.querySelector('aside.notes'); notes = a ? a.innerHTML : ''; }
        return { el: el, id: el.id || ('s' + (i + 1)), title: el.getAttribute('data-title') || textOf(h) || (T('슬라이드 ', 'Slide ') + (i + 1)), notesHTML: notes, steps: [], max: Object.keys(idx).length, hook: null, autoplay: 0 };
      });
      D.mode = 'reveal';
      var sync = function () {
        var cur = R.getCurrentSlide(), i = RevealAdapter.list.indexOf(cur);
        var f = R.getIndices().f;
        var st = { slide: Math.max(0, i), step: (typeof f === 'number' ? f + 1 : 0) };
        if (st.slide !== D.state.slide || st.step !== D.state.step) { D.state = st; afterChange(true); }
      };
      ['slidechanged', 'fragmentshown', 'fragmenthidden'].forEach(function (ev) { R.on(ev, sync); });
      sync();
    },
    count: function () { return D.slides.length; },
    max: function (i) { return D.slides[i] ? D.slides[i].max : 0; },
    apply: function (prev, next, animate) {
      var R = window.Reveal, el = this.list[next.slide];
      if (!el) return;
      var ix = R.getIndices(el);
      if (!animate) R.configure({ transition: 'none' });
      R.slide(ix.h, ix.v, next.step - 1);
      if (!animate && ROLE !== 'preview') setTimeout(function () { R.configure({ transition: RevealAdapter.transition || 'slide' }); }, 50);
    }
  };

  // ------------------------------------------------------------------ navigation
  function adapter() { return D.adapter || (D.mode === 'driver' ? Driver : Native); }

  function go(slide, step, animate, fromSync) {
    var A = adapter();
    var n = A.count();
    if (!n) return;
    slide = clamp(slide, 0, n - 1);
    step = clamp(step, 0, A.max(slide));
    var prev = D.state;
    if (prev.slide === slide && prev.step === step && D.ready) return;
    var next = { slide: slide, step: step };
    D.state = next;
    A.apply(prev, next, animate !== false);
    afterChange(!fromSync);
  }

  function next() {
    if (D.mode === 'driver') { var b0 = D.state; Driver.next(); if (b0.slide === D.state.slide && b0.step === D.state.step && D.state.slide >= D.slides.length - 1) toast(T('마지막 슬라이드입니다', 'This is the last slide')); return; }
    var A = adapter(), s = D.state;
    if (s.step < A.max(s.slide)) go(s.slide, s.step + 1, true);
    else if (s.slide < A.count() - 1) go(s.slide + 1, 0, true);
    else toast(T('마지막 슬라이드입니다', 'This is the last slide'));
  }
  function prev() {
    if (D.mode === 'driver') { Driver.prev(); return; }
    var A = adapter(), s = D.state;
    if (s.step > 0) go(s.slide, s.step - 1, false);
    else if (s.slide > 0) go(s.slide - 1, A.max(s.slide - 1), false);
  }

  var autoTimer = null;
  function afterChange(local) {
    clearTimeout(autoTimer);
    var s = D.slides[D.state.slide];
    if (ROLE === 'audience' && s && s.autoplay && D.state.step < s.max) {
      autoTimer = setTimeout(function () { if (D.state.slide === D.slides.indexOf(s)) next(); }, s.autoplay);
    }
    if (ROLE === 'audience') {
      if (resumeOffer && D.state.slide !== resumeOffer.from) resumeOffer = null; // moving on drops the "continue" offer
      if (D.mode !== 'driver') { try { history.replaceState(null, '', '#' + (D.state.slide + 1) + (D.state.step ? '.' + D.state.step : '')); } catch (e) { } }
      if (!resumeOffer && D.ready) store('hdek-pos:' + deckKey(), JSON.stringify({ slide: D.state.slide, step: D.state.step, t: Date.now() }));
      if (zoomRect) setZoom(null, true);
    }
    fit();
    renderInk();
    updateBar();
    Presenter.update();
    D.listeners.forEach(function (fn) { try { fn(D.state); } catch (e) { } });
    try { window.dispatchEvent(new CustomEvent('hdek:change', { detail: { slide: D.state.slide, step: D.state.step } })); } catch (e) { }
  }

  // Ink/position key: stays the same when slides are added; a fingerprint separates decks opened from the same page (player.html)
  var keyCache = null;
  function deckKey() {
    if (keyCache) return keyCache;
    var sig = D.slides.slice(0, 3).map(function (s) { return s.id + ':' + s.title; }).join('|'), h = 2166136261;
    for (var i = 0; i < sig.length; i++) { h ^= sig.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return (keyCache = (D.title + '|' + location.pathname).slice(0, 180) + '|' + h.toString(36));
  }
  function legacyKey() { return (D.title + '|' + D.slides.length + '|' + location.pathname).slice(0, 200); }

  function parseHash() {
    var m = /^#(\d+)(?:\.(\d+))?$/.exec(location.hash || '');
    return m ? { slide: +m[1] - 1, step: +(m[2] || 0) } : null;
  }

  // ------------------------------------------------------------------ stage fit
  function fit() {
    var W = D.width, H = D.height, vw = window.innerWidth, vh = window.innerHeight;
    var s = Math.min(vw / W, vh / H);
    var tf = 'translate(' + ((vw - W * s) / 2) + 'px,' + ((vh - H * s) / 2) + 'px) scale(' + s + ')';
    if (D.staged && D.root) {
      D.root.style.width = W + 'px';
      D.root.style.height = H + 'px';
      D.root.style.transform = tf;
    } else if (D.autostage && !document.documentElement.classList.contains('hdek-printing')) {
      D.slides.forEach(function (x, i) {
        if (i === D.state.slide) {
          x.el.style.setProperty('width', W + 'px', 'important');
          x.el.style.setProperty('height', H + 'px', 'important');
          x.el.style.setProperty('transform', tf, 'important');
        } else if (x.el.style.transform) { x.el.style.removeProperty('transform'); x.el.style.removeProperty('width'); x.el.style.removeProperty('height'); }
      });
    }
    positionInk();
  }

  // Lay the ink canvas exactly over the current slide (stage)
  function inkBox() {
    var el = D.staged ? D.root : (D.slides[D.state.slide] && D.slides[D.state.slide].el);
    var r = el && el !== document.body ? unzoom(el.getBoundingClientRect()) : null;
    if (!r || r.width < 50 || r.height < 50 || D.mode === 'single') r = { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight };
    return r;
  }

  // ------------------------------------------------------------------ zoom (magnifier)
  // zoomRect is the part of the slide that fills the screen, in slide fractions {x, y, w, h}; null = not zoomed.
  // The whole page is scaled (so ink and everything on the slide follow); the toolbar is scaled back.
  var zoomRect = null, uiHost = null, uiRoot = null, zoomBand = null;
  var FULL = { x: 0, y: 0, w: 1, h: 1 };
  var ZOOM_EASE = 'transform .28s cubic-bezier(.2,.7,.2,1)';
  function htmlMatrix() {
    try {
      var t = getComputedStyle(document.documentElement).transform;
      return t && t !== 'none' && window.DOMMatrix ? new DOMMatrix(t) : null;
    } catch (e) { return null; }
  }
  // a rectangle measured on screen, back in the page's own (unzoomed) coordinates
  function unzoom(r) {
    var m = htmlMatrix();
    if (!m || m.isIdentity) return r;
    var k = m.inverse(), p = k.transformPoint(new DOMPoint(r.left, r.top)), q = k.transformPoint(new DOMPoint(r.right, r.bottom));
    return { left: p.x, top: p.y, width: q.x - p.x, height: q.y - p.y, right: q.x, bottom: q.y };
  }
  function zoomXform(r, b, vw, vh) {
    var z = Math.min(vw / (r.w * b.width), vh / (r.h * b.height));
    var cx = b.left + (r.x + r.w / 2) * b.width, cy = b.top + (r.y + r.h / 2) * b.height;
    return { z: z, tx: vw / 2 - cx * z, ty: vh / 2 - cy * z };
  }
  // a point on screen (vw × vh view, slide box b) → slide fractions, taking the current zoom into account
  function viewToSlide(px, py, vw, vh, b) {
    if (zoomRect) { var X = zoomXform(zoomRect, b, vw, vh); px = (px - X.tx) / X.z; py = (py - X.ty) / X.z; }
    return [(px - b.left) / b.width, (py - b.top) / b.height];
  }
  function fitRect(r) {
    var w = clamp(r.w, 0.1, 1), h = clamp(r.h, 0.1, 1);
    return { x: clamp(r.x, 0, 1 - w), y: clamp(r.y, 0, 1 - h), w: w, h: h };
  }
  function applyZoom(instant) {
    var html = document.documentElement, st = html.style, tr = instant ? 'none' : ZOOM_EASE, hs = uiHost && uiHost.style;
    if (!zoomRect) {
      if (!st.transform && !html.classList.contains('hdek-zoomed')) return;
      st.transition = tr; st.transform = ''; html.classList.remove('hdek-zoomed');
      if (hs) { hs.transition = tr; hs.transform = ''; }
      return;
    }
    var b = inkBox(), X = zoomXform(zoomRect, b, window.innerWidth, window.innerHeight);
    html.classList.add('hdek-zoomed');
    st.transformOrigin = '0 0'; st.transition = tr;
    st.transform = 'translate(' + X.tx + 'px,' + X.ty + 'px) scale(' + X.z + ')';
    if (hs) { hs.transformOrigin = '0 0'; hs.transition = tr; hs.transform = 'scale(' + (1 / X.z) + ') translate(' + (-X.tx) + 'px,' + (-X.ty) + 'px)'; }
  }
  function setZoom(r, instant) {
    if (!r && !zoomRect) return;
    r = r ? fitRect(r) : null;
    if (r && r.w > 0.999 && r.h > 0.999) r = null;
    zoomRect = r;
    applyZoom(instant);
    Presenter.zoom(instant);
  }
  function zoomIn(p) { var c = zoomRect || FULL; setZoom({ x: p[0] - c.w / 4, y: p[1] - c.h / 4, w: c.w / 2, h: c.h / 2 }); }
  function zoomOut() {
    var c = zoomRect; if (!c) return;
    var cx = c.x + c.w / 2, cy = c.y + c.h / 2;
    setZoom({ x: cx - c.w, y: cy - c.h, w: c.w * 2, h: c.h * 2 });
  }
  function zoomBy(p, f) { var c = zoomRect || FULL; setZoom({ x: p[0] - (p[0] - c.x) * f, y: p[1] - (p[1] - c.y) * f, w: c.w * f, h: c.h * f }); }
  // a click zooms in 2× around the point, a drag zooms to the dragged area
  function zoomGesture(s0, e, map) {
    if (Math.abs(e.clientX - s0.x) < 12 && Math.abs(e.clientY - s0.y) < 12) { zoomIn(map(e.clientX, e.clientY)); return; }
    var a = map(s0.x, s0.y), b = map(e.clientX, e.clientY);
    setZoom({ x: Math.min(a[0], b[0]), y: Math.min(a[1], b[1]), w: Math.abs(a[0] - b[0]), h: Math.abs(a[1] - b[1]) });
  }
  function showBand(el, x0, y0, x1, y1) {
    if (!el) return;
    var s = el.style; s.display = 'block';
    s.left = Math.min(x0, x1) + 'px'; s.top = Math.min(y0, y1) + 'px'; s.width = Math.abs(x1 - x0) + 'px'; s.height = Math.abs(y1 - y0) + 'px';
  }
  var zoomWheelAcc = 0, zoomWheelLock = 0;
  function zoomWheel(e, p) {
    e.preventDefault();
    var now = Date.now();
    if (now < zoomWheelLock) return;
    zoomWheelAcc += e.deltaY;
    if (Math.abs(zoomWheelAcc) < 40) return;
    zoomBy(p, zoomWheelAcc < 0 ? 0.8 : 1.25);
    zoomWheelAcc = 0; zoomWheelLock = now + 90;
  }
  function onUI(t) { return !!(t && t.closest && t.closest('.hdek-ui-host')); }
  function bindZoom() {
    var start = null, map = function (x, y) { return viewToSlide(x, y, window.innerWidth, window.innerHeight, inkBox()); };
    window.addEventListener('pointerdown', function (e) {
      if (D.tool !== 'zoom' || e.button !== 0 || onUI(e.target)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      start = { x: e.clientX, y: e.clientY };
    }, true);
    window.addEventListener('pointermove', function (e) { if (start) showBand(zoomBand, start.x, start.y, e.clientX, e.clientY); }, true);
    window.addEventListener('pointerup', function (e) {
      if (!start) return;
      var s0 = start; start = null;
      if (zoomBand) zoomBand.style.display = 'none';
      inkClickBlock = Date.now() + 400;
      zoomGesture(s0, e, map);
    }, true);
  }
  function positionInk() {
    if (!inkCanvas) return;
    var r = inkBox();
    var st = inkCanvas.style;
    st.left = r.left + 'px'; st.top = r.top + 'px'; st.width = r.width + 'px'; st.height = r.height + 'px';
    Presenter.placeInk();
    renderInk();
  }

  // ------------------------------------------------------------------ ink
  var inkCanvas = null, laser = null, drawing = null, laserTrail = [];

  function Ink(canvas, boxFn) { this.c = canvas; this.box = boxFn; }
  Ink.prototype.size = function () {
    var b = this.box(), dpr = Math.min(2, (window.devicePixelRatio || 1) * (b.scale || 1));
    dpr *= Math.min(1, 4096 / Math.max(1, b.w * dpr, b.h * dpr)); // a zoomed presenter canvas can get very large
    var w = Math.max(1, Math.round(b.w * dpr)), h = Math.max(1, Math.round(b.h * dpr));
    if (this.c.width !== w || this.c.height !== h) { this.c.width = w; this.c.height = h; }
    return { w: w, h: h };
  };
  Ink.prototype.render = function (strokes, extra, laserPt, trail) {
    var sz = this.size(), ctx = this.c.getContext('2d');
    ctx.clearRect(0, 0, sz.w, sz.h);
    var all = (strokes || []).concat(extra ? [extra] : []);
    all.forEach(function (st) { drawStroke(ctx, st, sz.w, sz.h); });
    if (trail && trail.length) {
      for (var i = 1; i < trail.length; i++) {
        var a = trail[i - 1], b = trail[i], t = i / trail.length;
        ctx.strokeStyle = 'rgba(255,40,40,' + (0.35 * t) + ')';
        ctx.lineWidth = sz.h * 0.006 * t + 1; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(a[0] * sz.w, a[1] * sz.h); ctx.lineTo(b[0] * sz.w, b[1] * sz.h); ctx.stroke();
      }
    }
    if (laserPt) {
      var x = laserPt[0] * sz.w, y = laserPt[1] * sz.h, r = sz.h * 0.011;
      var g = ctx.createRadialGradient(x, y, 0, x, y, r * 2.6);
      g.addColorStop(0, 'rgba(255,60,60,1)'); g.addColorStop(0.35, 'rgba(255,30,30,.85)'); g.addColorStop(1, 'rgba(255,0,0,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 2.6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, r * 0.35, 0, Math.PI * 2); ctx.fill();
    }
  };

  function drawStroke(ctx, st, w, h) {
    var p = st.p; if (!p || !p.length) return;
    var base = st.w * h;
    ctx.save();
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = st.c; ctx.fillStyle = st.c;
    if (st.t === 'hl') { ctx.globalAlpha = 0.36; ctx.lineCap = 'butt'; }
    if (p.length === 1) {
      ctx.beginPath(); ctx.arc(p[0][0] * w, p[0][1] * h, base / 2, 0, Math.PI * 2); ctx.fill(); ctx.restore(); return;
    }
    if (st.t === 'hl') {
      ctx.lineWidth = base; ctx.beginPath(); ctx.moveTo(p[0][0] * w, p[0][1] * h);
      for (var k = 1; k < p.length; k++) ctx.lineTo(p[k][0] * w, p[k][1] * h);
      ctx.stroke(); ctx.restore(); return;
    }
    for (var i = 1; i < p.length; i++) {
      var a = p[i - 1], b = p[i], pr = ((a[2] || 0.5) + (b[2] || 0.5)) / 2;
      ctx.lineWidth = Math.max(1, base * (0.55 + pr * 0.9));
      ctx.beginPath();
      if (i > 1) {
        var z = p[i - 2];
        ctx.moveTo((z[0] + a[0]) / 2 * w, (z[1] + a[1]) / 2 * h);
        ctx.quadraticCurveTo(a[0] * w, a[1] * h, (a[0] + b[0]) / 2 * w, (a[1] + b[1]) / 2 * h);
      } else {
        ctx.moveTo(a[0] * w, a[1] * h); ctx.lineTo((a[0] + b[0]) / 2 * w, (a[1] + b[1]) / 2 * h);
      }
      ctx.stroke();
    }
    var l = p[p.length - 1], m = p[p.length - 2];
    ctx.beginPath(); ctx.moveTo((m[0] + l[0]) / 2 * w, (m[1] + l[1]) / 2 * h); ctx.lineTo(l[0] * w, l[1] * h); ctx.stroke();
    ctx.restore();
  }

  var inkAudience = null;
  function setupInk() {
    inkCanvas = document.createElement('canvas');
    inkCanvas.className = 'hdek-ink hdek-ui-ink hdek-fixed';
    document.body.appendChild(inkCanvas);
    inkAudience = new Ink(inkCanvas, function () { var r = inkBox(); return { w: r.width, h: r.height, scale: 1 }; });
    bindDraw(inkCanvas, window);
    try { var saved = JSON.parse(store('hdek-ink:' + deckKey()) || store('hdek-ink:' + legacyKey()) || 'null'); if (saved && typeof saved === 'object') D.ink = saved; } catch (e) { }
  }

  function resizeInk() { positionInk(); }

  var rafPending = false;
  function renderInk() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(function () {
      rafPending = false;
      var s = D.slides[D.state.slide], strokes = s ? (D.ink[s.id] || []) : [];
      var lp = laser && (Date.now() - laser.t < 2500) ? laser.p : null;
      if (inkAudience) inkAudience.render(strokes, drawing, lp, laserTrail);
      Presenter.renderInk(strokes, drawing, lp, laserTrail);
      if (lp) renderInk();
    });
  }

  var inkSaveTimer = null;
  function flushInk() { if (inkSaveTimer) { clearTimeout(inkSaveTimer); inkSaveTimer = null; store('hdek-ink:' + deckKey(), JSON.stringify(D.ink)); } }
  function saveInk() { if (!inkSaveTimer) inkSaveTimer = setTimeout(flushInk, 250); else { clearTimeout(inkSaveTimer); inkSaveTimer = setTimeout(flushInk, 250); } }

  function bindDraw(canvas, win) {
    var down = false, tempPen = false;
    function pt(e) {
      var r = canvas.getBoundingClientRect();
      var pr = e.pointerType === 'pen' ? (e.pressure || 0.5) : 0.5;
      return [clamp((e.clientX - r.left) / r.width, 0, 1), clamp((e.clientY - r.top) / r.height, 0, 1), pr];
    }
    function begin(e) {
      e.preventDefault();
      down = true;
      try { canvas.setPointerCapture(e.pointerId); } catch (x) { }
      var s = D.slides[D.state.slide]; if (!s) return;
      if (D.tool === 'eraser') { erase(pt(e)); return; }
      if (D.tool === 'laser') { moveLaser(pt(e)); return; }
      drawing = { t: D.tool, c: D.tool === 'hl' ? (D.color === '#111111' ? '#ffd60a' : D.color) : D.color, w: D.tool === 'hl' ? 0.026 : 0.0042, p: [pt(e)] };
      renderInk();
    }
    canvas.addEventListener('pointerdown', function (e) { if (D.tool && D.tool !== 'zoom' && !down) begin(e); });
    canvas.addEventListener('pointermove', function (e) {
      if (D.tool === 'laser') { moveLaser(pt(e)); return; }
      if (!down) return;
      if (D.tool === 'eraser') { erase(pt(e)); return; }
      if (!drawing) return;
      var evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
      if (!evs.length) evs = [e];
      evs.forEach(function (ev) { drawing.p.push(pt(ev)); });
      renderInk();
    });
    function end() {
      if (!down) return;
      down = false;
      if (drawing) {
        var s = D.slides[D.state.slide];
        drawing.p = drawing.p.map(function (q) { return [Math.round(q[0] * 1e4) / 1e4, Math.round(q[1] * 1e4) / 1e4, Math.round((q[2] || 0.5) * 100) / 100]; });
        if (s && drawing.p.length) { (D.ink[s.id] = D.ink[s.id] || []).push(drawing); saveInk(); }
        drawing = null;
        renderInk();
      }
      inkClickBlock = Date.now() + 400; // the click that follows a stroke must not advance the slide
      if (tempPen) { tempPen = false; setTool(null); }
    }
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    canvas.addEventListener('pointerleave', function () { if (D.tool === 'laser') { laser = null; laserTrail = []; renderInk(); } });
    // A stylus writes without picking a tool (as in Slidev)
    var target = canvas.ownerDocument;
    target.addEventListener('pointerdown', function (e) {
      if (e.pointerType === 'pen' && !D.tool && ROLE === 'audience' && !down) {
        var r = canvas.getBoundingClientRect();
        if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
          // the canvas was not hit-testable yet, so start the stroke here and keep the event from the deck
          tempPen = true; setTool('pen');
          e.stopImmediatePropagation();
          begin(e);
        }
      }
    }, true);
  }

  function moveLaser(p) {
    laser = { p: p, t: Date.now() };
    laserTrail.push([p[0], p[1]]);
    if (laserTrail.length > 14) laserTrail.shift();
    renderInk();
  }

  function erase(p) {
    var s = D.slides[D.state.slide]; if (!s || !D.ink[s.id]) return;
    var r = 0.02, before = D.ink[s.id].length;
    D.ink[s.id] = D.ink[s.id].filter(function (st) {
      return !st.p.some(function (q) { var dx = (q[0] - p[0]) * (16 / 9), dy = q[1] - p[1]; return dx * dx + dy * dy < r * r; });
    });
    if (D.ink[s.id].length !== before) { saveInk(); renderInk(); }
  }

  function clearInk(all) {
    if (all) D.ink = {};
    else { var s = D.slides[D.state.slide]; if (s) delete D.ink[s.id]; }
    saveInk(); flushInk(); renderInk();
    toast(all ? T('모든 필기를 지웠습니다', 'Cleared all ink') : T('이 슬라이드의 필기를 지웠습니다', 'Cleared ink on this slide'));
  }

  function setTool(t) {
    var was = D.tool;
    D.tool = (D.tool === t) ? null : t;
    if (t === null) D.tool = null;
    if (D.tool !== 'laser') { laser = null; laserTrail = []; }
    if (was === 'zoom' && !D.tool) setZoom(null); // turning the magnifier off zooms back out; other tools keep the zoom
    if (inkCanvas) { inkCanvas.classList.toggle('hdek-active', !!D.tool); inkCanvas.classList.toggle('hdek-zoomtool', D.tool === 'zoom'); if (D.tool) positionInk(); }
    Presenter.toolChanged();
    updateBar();
    renderInk();
  }

  // ------------------------------------------------------------------ blank
  var blankEl = null;
  function setBlank(kind) {
    D.blank = (D.blank === kind) ? null : kind;
    if (D.blank) setZoom(null, true);
    if (!blankEl) return;
    blankEl.className = 'hdek-blank' + (D.blank ? ' hdek-blank-on' : '');
    blankEl.style.background = D.blank === 'white' ? '#fff' : '#000';
    Presenter.update();
  }

  // ------------------------------------------------------------------ UI (audience)
  var bar = null, toastEl = null, gotoEl = null, helpEl = null, idleTimer = null;
  function setupUI() {
    blankEl = document.createElement('div'); blankEl.className = 'hdek-blank'; document.body.appendChild(blankEl);
    var host = uiHost = document.createElement('div'); host.className = 'hdek-ui hdek-ui-host';
    document.body.appendChild(host);
    uiRoot = host.attachShadow ? host.attachShadow({ mode: 'open' }) : host;
    var st = document.createElement('style'); st.textContent = UI_CSS; uiRoot.appendChild(st);
    if (uiRoot === host) injectCSS(document, UI_CSS.replace(':host{all:initial}', ''), 'hdek-ui-css');
    bar = document.createElement('div'); bar.className = 'hdek-ui hdek-bar';
    var html = '' +
      btn('prev', T('이전 (←)', 'Previous (←)')) + '<span class="hdek-num"></span>' + btn('next', T('다음 (→)', 'Next (→)')) +
      '<span class="sep"></span>' +
      btn('pen', T('펜 (D)', 'Pen (D)'), 'pen') + btn('hl', T('형광펜 (H)', 'Highlighter (H)'), 'hl') + btn('laser', T('레이저 (L)', 'Laser (L)'), 'laser') + btn('eraser', T('지우개 (E)', 'Eraser (E)'), 'eraser') + btn('zoom', T('돋보기 (Z)', 'Magnifier (Z)'), 'zoom') +
      COLORS.slice(0, 4).map(function (c) { return '<button class="hdek-swb" data-color="' + c + T('" title="색"><span class="hdek-sw" style="background:', '" title="Color"><span class="hdek-sw" style="background:') + c + '"></span></button>'; }).join('') +
      btn('clear', T('이 슬라이드 필기 지우기 (C)', 'Clear ink on this slide (C)')) +
      '<span class="sep"></span>' +
      btn('blank', T('검은 화면 (B)', 'Black screen (B)')) + btn('grid', T('슬라이드 한눈에 보기 · 검색 (G)', 'All slides · search (G)')) + btn('presenter', T('발표자 창 (S)', 'Presenter view (S)')) + btn('full', T('전체화면 / 프로젝터 (F)', 'Fullscreen / projector (F)')) + btn('help', T('단축키 (?)', 'Shortcuts (?)'));
    bar.innerHTML = html;
    function btn(name, title, tool) { return '<button data-act="' + name + '"' + (tool ? ' data-tool="' + tool + '"' : '') + ' title="' + title + '">' + svg(name) + '</button>'; }
    bar.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      e.stopPropagation();
      if (b.dataset.color) { D.color = b.dataset.color; if (!D.tool || D.tool === 'laser' || D.tool === 'eraser') setTool('pen'); else updateBar(); Presenter.toolChanged(); return; }
      action(b.dataset.act);
    });
    uiRoot.appendChild(bar);
    toastEl = document.createElement('div'); toastEl.className = 'hdek-ui hdek-toast'; uiRoot.appendChild(toastEl);
    gotoEl = document.createElement('div'); gotoEl.className = 'hdek-ui hdek-goto'; uiRoot.appendChild(gotoEl);
    helpEl = document.createElement('div'); helpEl.className = 'hdek-ui hdek-help'; helpEl.innerHTML = helpHTML(); uiRoot.appendChild(helpEl);
    helpEl.addEventListener('click', function () { helpEl.classList.remove('on'); });
    zoomBand = document.createElement('div'); zoomBand.className = 'hdek-ui hdek-zband'; uiRoot.appendChild(zoomBand);
    audGrid = SlideGrid(document, uiRoot, window);
    document.addEventListener('mousemove', function (e) {
      document.documentElement.classList.remove('hdek-idle');
      clearTimeout(idleTimer);
      var nearBottom = e.clientY > window.innerHeight - 140 && e.clientX < 880;
      bar.classList.toggle('show', nearBottom || bar.matches(':hover'));
      idleTimer = setTimeout(function () { if (!D.tool && !bar.matches(':hover')) { document.documentElement.classList.add('hdek-idle'); bar.classList.remove('show'); } }, 2200);
    });
    updateBar();
  }

  function updateBar() {
    if (!bar) return;
    var A = adapter(), s = D.state;
    var num = bar.querySelector('.hdek-num');
    if (num) num.textContent = (s.slide + 1) + ' / ' + A.count();
    $$('button[data-tool]', bar).forEach(function (b) { b.classList.toggle('on', b.dataset.tool === D.tool); });
    $$('button[data-color]', bar).forEach(function (b) { b.classList.toggle('on', b.dataset.color === D.color); });
  }

  function helpHTML() {
    var rows = [
      [T('다음 / 이전', 'Next / previous'), T('<kbd>→</kbd><kbd>Space</kbd><kbd>PgDn</kbd> 클릭·휠↓ / <kbd>←</kbd><kbd>PgUp</kbd> 오른쪽 클릭·휠↑', '<kbd>→</kbd><kbd>Space</kbd><kbd>PgDn</kbd> click · wheel ↓ / <kbd>←</kbd><kbd>PgUp</kbd> right-click · wheel ↑')],
      [T('처음 / 끝 · 이동', 'First / last · go to'), T('<kbd>Home</kbd> <kbd>End</kbd> · 숫자 + <kbd>Enter</kbd>', '<kbd>Home</kbd> <kbd>End</kbd> · number + <kbd>Enter</kbd>')],
      [T('슬라이드 한눈에 보기 · 검색', 'All slides · search'), '<kbd>G</kbd>'],
      [T('지난번 멈춘 곳에서 이어서', 'Continue where you stopped'), T('<kbd>R</kbd> (덱을 연 직후)', '<kbd>R</kbd> (right after opening)')],
      [T('돋보기', 'Magnifier'), T('<kbd>Z</kbd> 후 클릭(2배) · 드래그(그 영역) · 휠, 오른쪽 클릭 축소', '<kbd>Z</kbd>, then click (2×) · drag (that area) · wheel; right-click zooms out')],
      [T('영상 재생 / 일시정지', 'Play / pause video'), '<kbd>K</kbd>'],
      [T('발표자 창', 'Presenter view'), '<kbd>S</kbd>'],
      [T('전체화면 · 프로젝터로', 'Fullscreen · to projector'), '<kbd>F</kbd>'],
      [T('검은 / 흰 화면', 'Black / white screen'), '<kbd>B</kbd> <kbd>.</kbd> / <kbd>W</kbd>'],
      [T('펜 · 형광펜 · 레이저 · 지우개', 'Pen · highlighter · laser · eraser'), T('<kbd>D</kbd> <kbd>H</kbd> <kbd>L</kbd> <kbd>E</kbd> (펜 태블릿은 바로 필기)', '<kbd>D</kbd> <kbd>H</kbd> <kbd>L</kbd> <kbd>E</kbd> (a stylus draws right away)')],
      [T('필기 지우기 / 모두', 'Clear ink / all'), '<kbd>C</kbd> / <kbd>Shift</kbd>+<kbd>C</kbd>'],
      [T('도구 끄기', 'Tool off'), '<kbd>Esc</kbd>'],
      [T('인쇄 · PDF', 'Print · PDF'), T('<kbd>Ctrl</kbd>/<kbd>⌘</kbd>+<kbd>P</kbd> (모든 단계가 펼쳐진 상태로)', '<kbd>Ctrl</kbd>/<kbd>⌘</kbd>+<kbd>P</kbd> (every step revealed)')]
    ];
    return '<div class="hdek-card"><h3>' + PRODUCT + T(' 단축키</h3><table>', ' shortcuts</h3><table>') + rows.map(function (r) { return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>'; }).join('') + '</table></div>';
  }

  var toastTimer = null;
  function toast(msg, ms) {
    if (!toastEl || ROLE !== 'audience') return;
    toastEl.textContent = msg; toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, ms || 1800);
  }

  // ------------------------------------------------------------------ fullscreen / projector
  // Screens (Window Management API, Chrome/Edge). Cached once the user has allowed it, because fullscreen on
  // another screen and the presenter popup must both start inside the same key press.
  var screens = null;
  function loadScreens(ask) {
    if (!('getScreenDetails' in window)) return Promise.resolve(null);
    var get = function () { return window.getScreenDetails().then(function (sd) { screens = sd; return sd; }); };
    if (ask) return get().catch(function () { return null; });
    try {
      return navigator.permissions.query({ name: 'window-management' }).then(function (st) { return st.state === 'granted' ? get() : null; }).catch(function () { return null; });
    } catch (e) { return Promise.resolve(null); }
  }
  function projectorOf(sd) {
    if (!sd) return null;
    var cur = sd.currentScreen;
    return sd.screens.filter(function (x) { return x !== cur; }).sort(function (a, b) { return (a.isInternal ? 1 : 0) - (b.isInternal ? 1 : 0); })[0] || null;
  }
  function isFull() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }

  // S: presenter view on this screen and the slides fullscreen on the projector, in one key press
  function startPresenting() {
    if (ROLE !== 'audience') return;
    if (Presenter.isOpen()) { Presenter.open(); return; }
    var extended = !!(window.screen && window.screen.isExtended);
    var target = extended ? projectorOf(screens) : null;
    var el = document.documentElement;
    if (target && !isFull() && el.requestFullscreen) {
      var here = screens.currentScreen;
      // Chrome lets a page go fullscreen on another screen and open a "companion" popup from one gesture
      try { var r = el.requestFullscreen({ screen: target }); if (r && r.catch) r.catch(function () { }); } catch (e) { }
      Presenter.open(here, true);
      return;
    }
    Presenter.open();
    if (extended && !screens && 'getScreenDetails' in window) {
      // first time: ask for the "window management" permission; from then on S does both at once
      loadScreens(true).then(function (sd) {
        if (sd) toast(T('허용되었습니다. 지금은 청중 창에서 F를 누르세요. 다음부터는 S 한 번으로 프로젝터 전체화면까지 됩니다', 'Allowed. Press F in the audience window now; next time S also puts the slides fullscreen on the projector'), 6000);
      });
    } else if (window.screen && window.screen.isExtended === false && 'getScreenDetails' in window) {
      toast(T('화면이 하나이거나 복제 모드입니다. 프로젝터를 "확장" 모드로 연결하세요 (Windows: Win+P)', 'One screen, or the displays are mirrored. Set the projector to "Extend" (Windows: Win+P)'), 6000);
    }
  }

  function toggleFullscreen() {
    var doc = document;
    if (doc.fullscreenElement || doc.webkitFullscreenElement) {
      (doc.exitFullscreen || doc.webkitExitFullscreen).call(doc);
      return;
    }
    var el = doc.documentElement;
    var req = el.requestFullscreen || el.webkitRequestFullscreen;
    if (!req) { toast(T('이 브라우저는 전체화면을 지원하지 않습니다', 'This browser does not support fullscreen')); return; }
    var plain = function () {
      try { var r = req.call(el); if (r && r.catch) r.catch(function () { toast(T('한 번 더 F를 눌러 주세요', 'Press F once more')); }); } catch (e) { }
    };
    if (!('getScreenDetails' in window) || !(window.screen && window.screen.isExtended)) { plain(); return; }
    var go2 = function (sd) {
      var target = projectorOf(sd);
      if (!target) { plain(); return; }
      var r = req.call(el, { screen: target });
      if (r && r.catch) r.catch(plain);
      toast(T('프로젝터 화면에 전체화면으로 표시합니다', 'Showing fullscreen on the projector'));
    };
    if (screens) { go2(screens); return; } // already allowed: stay inside the key press
    loadScreens(true).then(function (sd) { if (sd) go2(sd); else plain(); });
  }

  // ------------------------------------------------------------------ input
  var gotoBuf = '', gotoTimer = null;
  function action(a, ev) {
    switch (a) {
      case 'next': next(); break;
      case 'prev': prev(); break;
      case 'first': go(0, 0, true); break;
      case 'last': go(adapter().count() - 1, adapter().max(adapter().count() - 1), false); break;
      case 'pen': setTool('pen'); break;
      case 'hl': setTool('hl'); break;
      case 'laser': setTool('laser'); break;
      case 'eraser': setTool('eraser'); break;
      case 'clear': clearInk(ev && ev.shiftKey); break;
      case 'clearall': clearInk(true); break;
      case 'blank': setBlank('black'); break;
      case 'white': setBlank('white'); break;
      case 'presenter': startPresenting(); break;
      case 'zoom': setTool('zoom'); break;
      case 'grid':
        // G in the presenter view opens the overview there; in the audience window it opens on the slides
        if (Presenter.isOpen() && !(ev && ev.view === window)) Presenter.grid().open();
        else if (audGrid) { setZoom(null, true); audGrid.open(); }
        break;
      case 'media': {
        var ms = currentMedia();
        if (!ms.length) toast(T('이 슬라이드에는 영상이 없습니다', 'No video on this slide'));
        else togglePlay(ms[0]);
        break;
      }
      case 'resume': if (resumeOffer) { var ro = resumeOffer; resumeOffer = null; go(ro.slide, ro.step, false); Presenter.update(); } break;
      case 'full': toggleFullscreen(); break;
      case 'help': if (helpEl) helpEl.classList.toggle('on'); break;
      case 'print': window.print(); break;
    }
  }

  function keyAction(e) {
    var k = e.key;
    if (e.altKey || (e.ctrlKey && k !== 'F5') || e.metaKey) return null;
    switch (k) {
      case 'ArrowRight': case 'ArrowDown': case 'PageDown': case ' ': return 'next';
      case 'n': case 'N': return D.mode === 'driver' ? null : 'next';
      case 'ArrowLeft': case 'ArrowUp': case 'PageUp': case 'Backspace': return 'prev';
      case 'p': case 'P': return D.mode === 'driver' ? null : 'prev';
      case 'Home': return 'first';
      case 'End': return 'last';
      case 's': case 'S': return 'presenter';
      case 'f': case 'F': case 'F5': return 'full';
      case 'b': case 'B': case '.': return 'blank';
      case 'w': case 'W': case ',': return 'white';
      case 'd': case 'D': return 'pen';
      case 'h': case 'H': return 'hl';
      case 'l': case 'L': return 'laser';
      case 'e': case 'E': return 'eraser';
      case 'c': case 'C': return 'clear';
      case 'z': case 'Z': return 'zoom';
      case 'g': case 'G': return 'grid';
      case 'k': case 'K': return 'media';
      case 'r': case 'R': return resumeOffer ? 'resume' : null; // otherwise the key stays the deck's
      case '?': return 'help';
    }
    return null;
  }

  var REVEAL_OWN = { next: 1, prev: 1, first: 1, last: 1 };
  var NAV = { next: 1, prev: 1, first: 1, last: 1 };
  // Give the deck the first chance. Some decks move on keyup or after a short timer,
  // so we act only if nothing changed by the time the key is released and ~300 ms have passed.
  function afterDeck(fn, keyEv) {
    var before = Driver.read(), t0 = Date.now(), released = !keyEv;
    var onUp = function (e) { if (!keyEv || e.key === keyEv.key) { released = true; w.removeEventListener('keyup', onUp, true); } };
    var w = (keyEv && keyEv.view) || window;
    if (keyEv) { try { w.addEventListener('keyup', onUp, true); } catch (x) { released = true; } }
    (function poll() {
      var n = Driver.read();
      if (n.slide !== before.slide || n.step !== before.step) { Driver.sync(); return; }
      if (released && Date.now() - t0 >= 300) { fn(); return; }
      if (Date.now() - t0 > 1500) released = true;
      setTimeout(poll, 30);
    })();
  }
  function gridFor(e) {
    var v = e && e.view;
    if (audGrid && audGrid.isOpen() && v === window) return audGrid;
    var pg = Presenter.grid();
    if (pg && pg.isOpen() && v && v !== window) return pg;
    return null;
  }
  function handleKey(e) {
    if (e.__hdek) return;
    var g = gridFor(e);
    if (g) { g.key(e); return; } // the overview has the keyboard (search box, arrows, Enter, Esc)
    // clickers send PageUp/PageDown: they must work even while a text field has focus
    if (isTyping(e.target) && e.key !== 'PageDown' && e.key !== 'PageUp') return;
    var k = e.key;
    if (/^[0-9]$/.test(k) && !e.ctrlKey && !e.metaKey && !e.altKey) {
      gotoBuf += k; showGoto(); e.preventDefault(); e.stopImmediatePropagation(); return;
    }
    if (k === 'Enter') {
      if (gotoBuf) { var n = parseInt(gotoBuf, 10); gotoBuf = ''; showGoto(); if (n > 0) go(n - 1, 0, false); e.preventDefault(); e.stopImmediatePropagation(); return; }
      if (D.mode === 'driver') { afterDeck(next, e); return; }
      if (D.mode !== 'reveal') { next(); e.preventDefault(); }
      return;
    }
    if (k === 'Escape') {
      if (gotoBuf) { gotoBuf = ''; showGoto(); return; }
      if (helpEl && helpEl.classList.contains('on')) { helpEl.classList.remove('on'); return; }
      if (D.tool) { setTool(null); return; }
      if (zoomRect) { setZoom(null); return; }
      if (D.blank) { setBlank(D.blank); return; }
      return;
    }
    var a = keyAction(e);
    if (!a) return;
    if (D.mode === 'reveal' && REVEAL_OWN[a] && ROLE === 'audience' && e.currentTarget === window) return; // reveal handles it
    if (D.mode === 'driver' && NAV[a] && e.currentTarget === window) {
      // Let the deck's engine go first; handle only keys it ignores (↓, ↑, …)
      afterDeck(function () { action(a, e); }, e);
      return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
    action(a, e);
  }
  function showGoto() {
    if (!gotoEl) return;
    clearTimeout(gotoTimer);
    gotoEl.style.display = gotoBuf ? 'block' : 'none';
    gotoEl.textContent = gotoBuf ? (gotoBuf + T(' 번 슬라이드로 → Enter', ' → Enter to go to slide')) : '';
    Presenter.showGoto(gotoBuf);
    if (gotoBuf) gotoTimer = setTimeout(function () { gotoBuf = ''; showGoto(); }, 4000);
  }

  function isInteractive(t, slideEl) {
    if (!t || !t.closest) return false;
    if (t.closest('a, button, input, select, textarea, label, summary, details, video, audio, iframe, [contenteditable], [data-interactive], [onclick], .hdek-ui')) return true;
    var el = t;
    while (el && el !== slideEl && el !== document.body && el.nodeType === 1) {
      try { if (getComputedStyle(el).cursor === 'pointer') return true; } catch (e) { }
      el = el.parentElement;
    }
    return false;
  }

  var wheelLock = 0, wheelAcc = 0, inkClickBlock = 0;
  function bindInput() {
    window.addEventListener('keydown', handleKey, true);
    // Capture phase: a click anywhere on the slide moves forward, and the deck's own click handler must not
    // also act (many AI decks go back when the left third is clicked; in a talk a click should always advance).
    // Buttons, links and other interactive elements keep working as the deck intended.
    window.addEventListener('click', function (e) {
      if (Date.now() < inkClickBlock) { e.stopImmediatePropagation(); e.preventDefault(); return; } // the click that ends a pen stroke
      if (!D.clickAdvance || D.tool || e.button !== 0) return;
      if (D.mode === 'single' || D.mode === 'reveal') return;
      var s = D.slides[D.state.slide];
      if (isInteractive(e.target, s && s.el)) return;
      var sel = window.getSelection && window.getSelection();
      if (sel && String(sel).length > 0) return;
      e.stopImmediatePropagation();
      next();
    }, true);
    // Right-click goes back (the browser menu is not shown on the slides)
    window.addEventListener('contextmenu', function (e) {
      if (D.tool === 'zoom' && !onUI(e.target)) { e.preventDefault(); e.stopImmediatePropagation(); zoomOut(); return; }
      if (!D.clickAdvance || D.tool || D.mode === 'single') return;
      if (isTyping(e.target) || (e.target && e.target.closest && e.target.closest('.hdek-ui, a, input, textarea, select, [contenteditable]'))) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      prev();
    }, true);
    window.addEventListener('wheel', function (e) {
      if (audGrid && audGrid.isOpen()) return; // the overview scrolls
      if (D.tool === 'zoom' && !onUI(e.target)) { e.stopImmediatePropagation(); zoomWheel(e, viewToSlide(e.clientX, e.clientY, window.innerWidth, window.innerHeight, inkBox())); return; }
      if (!D.wheelAdvance || e.ctrlKey || D.mode === 'single') return;
      var el = e.target;
      while (el && el !== document.body && el.nodeType === 1) {
        var cs = getComputedStyle(el);
        if (/(auto|scroll)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 2) return;
        el = el.parentElement;
      }
      e.preventDefault();
      if (D.mode !== 'reveal') e.stopImmediatePropagation(); // one wheel step = one move, even if the deck listens too
      var now = Date.now();
      // trackpad momentum keeps sending events: one swipe = one step, so wait for a quiet gap
      if (now < wheelLock) { wheelLock = Math.max(wheelLock, now + 180); return; }
      wheelAcc += e.deltaY;
      if (Math.abs(wheelAcc) < 30) return;
      if (wheelAcc > 0) next(); else prev();
      wheelAcc = 0; wheelLock = now + 450;
    }, { passive: false, capture: true });
    // Touch swipes: touch events still arrive when the browser takes the gesture for panning
    var sx = null, sy = null;
    document.addEventListener('touchstart', function (e) { if (!D.tool && e.touches.length === 1) { sx = e.touches[0].clientX; sy = e.touches[0].clientY; } else sx = null; }, { passive: true });
    document.addEventListener('touchend', function (e) {
      if (sx === null || !e.changedTouches.length) return;
      var t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy; sx = null;
      if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) {
        var f = dx < 0 ? next : prev;
        if (D.mode === 'driver') afterDeck(f); else f();
      }
    }, { passive: true });
    bindZoom();
    window.addEventListener('resize', function () { fit(); if (zoomRect) applyZoom(true); Presenter.layout(); });
    // the slide may still be animating into place when it becomes current: re-fit the ink canvas when it settles
    ['transitionend', 'animationend'].forEach(function (t) {
      document.addEventListener(t, function (e) { var s = D.slides[D.state.slide]; if (s && e.target === s.el) positionInk(); }, true);
    });
    window.addEventListener('pagehide', flushInk);
    window.addEventListener('beforeunload', function () { Presenter.close(); });
    window.addEventListener('beforeprint', printPrepare);
    window.addEventListener('afterprint', printRestore);
  }

  // ------------------------------------------------------------------ print
  var printStyle = null, printAdded = [], printSaved = null;
  function printPrepare() {
    setZoom(null, true);
    var html = document.documentElement;
    html.classList.add('hdek-printing', 'hdek-snap');
    var fixed = D.staged || D.autostage || D.mode === 'driver';
    var W = fixed ? D.width : window.innerWidth, H = fixed ? D.height : window.innerHeight;
    var css = '@page{size:' + W + 'px ' + H + 'px;margin:0}' +
      '@media print{html,body{background:#fff!important;overflow:visible!important;height:auto!important;margin:0!important;padding:0!important}' +
      (D.staged ? '.hdek-stage{position:static!important;transform:none!important;width:auto!important;height:auto!important;overflow:visible!important}' : '') +
      '.hdek-print-anc{position:static!important;transform:none!important;width:auto!important;height:auto!important;overflow:visible!important;display:block!important;padding:0!important;margin:0!important;gap:0!important;inset:auto!important;zoom:1!important}' +
      '.hdek-slide{position:relative!important;box-sizing:border-box!important;width:' + W + 'px!important;height:' + H + 'px!important;break-after:page;page-break-after:always;overflow:hidden!important;inset:auto!important;left:auto!important;top:auto!important;transform:none!important;margin:0!important;zoom:1!important;opacity:1!important;visibility:visible!important;box-shadow:none!important}' +
      '.hdek-ink,.hdek-backdrop,.hdek-notes-src,.hdek-print-hide{display:none!important}}';
    printStyle = injectCSS(document, css, 'hdek-print-css');
    if (D.mode === 'reveal') return;
    printAdded = [];
    if (D.autostage) D.slides.forEach(function (x) { ['transform', 'width', 'height'].forEach(function (k) { x.el.style.removeProperty(k); }); });
    function addCls(el, c) { if (!el.classList.contains(c)) { el.classList.add(c); printAdded.push([el, c]); } }
    if (!D.staged && D.mode !== 'single') {
      D.slides.forEach(function (s) {
        for (var a = s.el.parentElement; a && a !== document.body && a !== document.documentElement; a = a.parentElement) addCls(a, 'hdek-print-anc');
      });
      // Leave deck UI that is not a slide or its ancestor (progress bar, buttons, notes panel) out of print
      [document.body].concat($$('.hdek-print-anc')).forEach(function (a) {
        Array.prototype.forEach.call(a.children, function (c) {
          if (c.classList.contains('hdek-print-anc') || c.classList.contains('hdek-slide') || /^(SCRIPT|STYLE|LINK|META)$/.test(c.tagName)) return;
          addCls(c, 'hdek-print-hide');
        });
      });
    }
    if (D.mode === 'driver') {
      Driver.paused = true; printSaved = { slide: D.state.slide, step: D.state.step };
      D.slides.forEach(function (s) {
        addCls(s.el, Driver.activeClass);
        Driver.stepsOf(s.el).forEach(function (e) { addCls(e, 'on'); addCls(e, 'is-on'); addCls(e, 'visible'); });
        $$('[data-type]', s.el).forEach(function (e) { if (!e.textContent) e.textContent = e.getAttribute('data-type'); });
        void s.el.offsetWidth; finishAnimations(s.el);
      });
      return;
    }
    D.slides.forEach(function (s) {
      s.el.classList.add('active', 'is-active', 'present');
      setSteps(s, s.max, false);
      void s.el.offsetWidth;
      finishAnimations(s.el);
    });
  }
  function printRestore() {
    var html = document.documentElement;
    html.classList.remove('hdek-printing');
    if (printStyle) { printStyle.remove(); printStyle = null; }
    printAdded.forEach(function (x) { x[0].classList.remove(x[1]); });
    printAdded = [];
    if (D.mode === 'driver') {
      Driver.paused = false;
      var back = printSaved || D.state; printSaved = null;
      var now = Driver.read();
      if (now.slide !== back.slide || now.step !== back.step) Driver.apply(now, back, false);
      Driver.sync(); fit(); requestAnimationFrame(function () { html.classList.remove('hdek-snap'); });
      return;
    }
    fit();
    if (D.mode !== 'reveal') {
      D.slides.forEach(function (s, i) {
        if (i !== D.state.slide) { s.el.classList.remove('active', 'is-active', 'present'); setSteps(s, 0, false); }
      });
      setSteps(D.slides[D.state.slide], D.state.step, false);
    }
    requestAnimationFrame(function () { html.classList.remove('hdek-snap'); });
  }

  // ------------------------------------------------------------------ presenter
  var Presenter = (function () {
    var w = null, els = {}, ready = { cur: false, nxt: false }, queued = {}, inkP = null;
    var timer = { start: 0, acc: 0, running: false }, tick = null;
    var notesSize = parseInt(store('hdek-notes-size') || '22', 10);
    var showCurLive = store('hdek-cur-live') !== 'off';
    var pgrid = null, media = [], mediaSlide = -1, mediaSeek = -1, mtick = null, noteTimer = null;
    var aspect = slideAspect;

    function open(onScreen, withShow) {
      if (ROLE !== 'audience') return;
      if (w && !w.closed) { try { w.focus(); } catch (e) { } return; }
      var feat = 'popup=yes,width=1280,height=800';
      // put the presenter view on the laptop screen, filling it, while the slides go to the projector
      if (onScreen) feat = 'popup=yes,left=' + onScreen.availLeft + ',top=' + onScreen.availTop + ',width=' + onScreen.availWidth + ',height=' + onScreen.availHeight;
      w = window.open('', 'hdek-presenter', feat);
      if (!w) { toast(T('팝업이 차단되었습니다. 주소창의 팝업 허용 후 다시 S를 눌러 주세요', 'Popup blocked. Allow popups in the address bar, then press S again'), 4000); return; }
      try { w.document; } catch (e) { toast(T('발표자 창을 열 수 없습니다 (보안 설정)', 'Cannot open the presenter view (security settings)')); w = null; return; }
      build();
      if (!timer.running && !timer.acc) startTimer();
      if (!withShow) toast(T('발표자 창을 열었습니다. 이 창을 프로젝터로 옮기고 F를 누르세요', 'Presenter view opened. Move this window to the projector and press F'), 3200);
    }

    function close() { try { if (w && !w.closed) w.close(); } catch (e) { } w = null; }

    function build() {
      try { if (tick) w.clearInterval(tick); if (mtick) w.clearInterval(mtick); } catch (e) { }
      var doc = w.document;
      doc.open();
      doc.write(T('<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>발표자 화면 — ', '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Presenter view — ') + escapeHTML(D.title) + '</title></head><body></body></html>');
      doc.close();
      injectCSS(doc, PRESENTER_CSS + '\n' + GRID_CSS);
      doc.body.innerHTML = PRESENTER_HTML;
      els = {};
      ['cur', 'curbox', 'nxt', 'nxtbox', 'notes', 'num', 'stepn', 'elapsed', 'remain', 'clock', 'prog', 'dur', 'title', 'goto', 'hint', 'blankst', 'tools', 'endcard', 'curoff', 'media', 'resume', 'note', 'zband'].forEach(function (id) { els[id] = doc.getElementById(id); });
      if (pgrid) pgrid.close();
      pgrid = SlideGrid(doc, doc.body, w);
      media = []; mediaSlide = -1; mediaSeek = -1;
      els.title.textContent = D.title;
      els.notes.style.fontSize = notesSize + 'px';
      if (D.duration) els.dur.value = D.duration;
      ready = { cur: false, nxt: false }; queued = {};
      var a = aspect(), url = deckURL();
      els.curframe = mkFrame(doc, 'hdek-preview-cur', url, a, 'cur');
      els.nxtframe = mkFrame(doc, 'hdek-preview-nxt', url, a, 'nxt');
      els.curbox.insertBefore(els.curframe, els.curbox.firstChild);
      els.nxtbox.insertBefore(els.nxtframe, els.nxtbox.firstChild);
      els.curoff.style.display = showCurLive ? 'none' : 'grid';
      // ink on presenter
      var pc = doc.createElement('canvas'); pc.className = 'pink'; els.curbox.appendChild(pc);
      inkP = new Ink(pc, function () { var r = pc.getBoundingClientRect(); return { w: r.width || 1, h: r.height || 1, scale: 1 }; });
      els.pink = pc;
      bindDraw(pc, w);
      w.addEventListener('message', onMsg);
      w.addEventListener('keydown', handleKey, true);
      w.addEventListener('resize', layout);
      w.addEventListener('beforeunload', function () { w = null; });
      doc.addEventListener('click', onClick);
      doc.addEventListener('wheel', onWheel, { passive: false });
      doc.addEventListener('contextmenu', function (e) {
        var t = e.target;
        if (!t.closest || t.closest('#media')) return;
        if (D.tool === 'zoom' && t.closest('#curbox')) { e.preventDefault(); zoomOut(); return; }
        if (D.tool || !t.closest('#cur, #nxt')) return;
        e.preventDefault();
        prev();
      });
      // magnifier on the current-slide preview: click = 2×, drag = that area
      var zs = null;
      els.curbox.addEventListener('pointerdown', function (e) {
        if (D.tool !== 'zoom' || e.button !== 0) return;
        e.preventDefault();
        zs = { x: e.clientX, y: e.clientY };
      });
      doc.addEventListener('pointermove', function (e) {
        if (!zs) return;
        var r = els.curbox.getBoundingClientRect();
        showBand(els.zband, zs.x - r.left, zs.y - r.top, e.clientX - r.left, e.clientY - r.top);
      });
      doc.addEventListener('pointerup', function (e) {
        if (!zs) return;
        var s0 = zs; zs = null;
        els.zband.style.display = 'none';
        inkClickBlock = Date.now() + 400;
        zoomGesture(s0, e, previewPoint);
      });
      // video controls under the current slide
      els.media.addEventListener('pointerdown', function (e) { var r = e.target.closest && e.target.closest('input[data-m]'); if (r) mediaSeek = +r.closest('.mrow').dataset.i; });
      els.media.addEventListener('input', function (e) {
        var r = e.target; if (!r.matches || !r.matches('input[data-m]')) return;
        var i = +r.closest('.mrow').dataset.i, m = media[i]; mediaSeek = i;
        if (m && isFinite(m.duration) && m.duration > 0) { try { m.currentTime = (+r.value / 1000) * m.duration; } catch (x) { } }
      });
      els.media.addEventListener('change', function (e) { mediaSeek = -1; if (e.target.blur) e.target.blur(); tickMedia(); });
      w.addEventListener('pointerup', function () { if (mediaSeek >= 0) setTimeout(function () { mediaSeek = -1; }, 50); });
      doc.getElementById('notesminus').addEventListener('click', function () { setNotes(-2); });
      doc.getElementById('notesplus').addEventListener('click', function () { setNotes(2); });
      els.dur.addEventListener('change', function () { D.duration = parseFloat(els.dur.value) || 0; tickTimer(); els.dur.blur(); });
      els.dur.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === 'Escape') els.dur.blur(); });
      els.elapsed.addEventListener('click', toggleTimer);
      layout();
      setTimeout(layout, 60);
      tick = w.setInterval(tickTimer, 500);
      mtick = w.setInterval(tickMedia, 250);
      toolChanged();
      update();
      pinkZoom(true);
      if (zoomRect) post('cur', { hdek: 1, type: 'zoom', r: zoomRect, instant: true });
    }

    // a point in the presenter window → slide fractions of the audience view
    function previewBox(a) { return (D.staged || D.mode === 'reveal') ? { left: 0, top: 0, width: a.w, height: a.h } : inkBox(); }
    function previewPoint(cx, cy) {
      var a = aspect(), r = els.curbox.getBoundingClientRect(), s = r.width / a.w || 1;
      return viewToSlide((cx - r.left) / s, (cy - r.top) / s, a.w, a.h, previewBox(a));
    }
    // follow the audience zoom: the preview zooms itself, the ink canvas over it gets the same transform
    function zoomP(instant) {
      if (!w || w.closed) return;
      post('cur', { hdek: 1, type: 'zoom', r: zoomRect, instant: !!instant });
      pinkZoom(instant);
    }
    function pinkZoom(instant) {
      if (!els.pink) return;
      var st = els.pink.style;
      st.transition = instant ? 'none' : ZOOM_EASE;
      if (!zoomRect) { st.transform = ''; return; }
      var a = aspect(), r = els.curbox.getBoundingClientRect(), s = r.width / a.w || 1, b = previewBox(a), X = zoomXform(zoomRect, b, a.w, a.h);
      st.transformOrigin = (-b.left * s) + 'px ' + (-b.top * s) + 'px';
      st.transform = 'translate(' + (X.tx * s) + 'px,' + (X.ty * s) + 'px) scale(' + X.z + ')';
    }

    // ---- video and audio on the current slide: controlled here, played on the projector
    function renderMedia() {
      if (!els.media) return;
      media = currentMedia().slice(0, 3);
      mediaSlide = D.state.slide;
      els.media.innerHTML = media.map(function (m, i) {
        return '<div class="mrow" data-i="' + i + '">' +
          (media.length > 1 ? '<span class="mi">' + (m.tagName === 'AUDIO' ? '♪' : '▶') + (i + 1) + '</span>' : '') +
          '<button data-m="play" title="' + T('재생 / 일시정지 (K)', 'Play / pause (K)') + '">' + svg('play') + '</button>' +
          '<button data-m="back" title="' + T('10초 뒤로', 'Back 10 s') + '">−10</button>' +
          '<input type="range" min="0" max="1000" value="0" step="1" data-m="seek" title="' + T('재생 위치', 'Position') + '">' +
          '<button data-m="fwd" title="' + T('10초 앞으로', 'Forward 10 s') + '">+10</button>' +
          '<span class="mt">0:00</span>' +
          '<button data-m="mute" title="' + T('소리 켜기 / 끄기', 'Sound on / off') + '">' + svg('vol') + '</button></div>';
      }).join('');
      els.cur.classList.toggle('hasmedia', media.length > 0);
      els.cur.style.setProperty('--mrows', String(media.length));
      layout();
      pinkZoom(true);
      tickMedia();
    }
    function tickMedia() {
      if (!w || w.closed || !els.media) return;
      var now = currentMedia().slice(0, 3);
      if (D.state.slide !== mediaSlide || now.length !== media.length || now.some(function (m, i) { return m !== media[i]; })) { renderMedia(); return; }
      if (!media.length) return;
      var list = media.map(function (m, i) {
        var row = els.media.children[i]; if (!row) return null;
        var d = m.duration, t = m.currentTime || 0, playing = !m.paused && !m.ended;
        var pb = row.querySelector('[data-m="play"]'), mb = row.querySelector('[data-m="mute"]'), rg = row.querySelector('input');
        if (pb.__p !== playing) { pb.innerHTML = svg(playing ? 'pause' : 'play'); pb.__p = playing; pb.classList.toggle('on', playing); }
        if (mb.__m !== m.muted) { mb.innerHTML = svg(m.muted ? 'mute' : 'vol'); mb.__m = m.muted; }
        if (mediaSeek !== i && isFinite(d) && d > 0) rg.value = String(Math.round(t / d * 1000));
        row.querySelector('.mt').textContent = fmtTime(t) + ' / ' + (isFinite(d) && d > 0 ? fmtTime(d) : '–:––');
        return { t: t, p: playing };
      });
      post('cur', { hdek: 1, type: 'media', slide: D.state.slide, list: list });
    }
    function mediaCmd(i, c) {
      var m = media[i]; if (!m) return;
      try {
        if (c === 'play') togglePlay(m);
        else if (c === 'back') m.currentTime = Math.max(0, (m.currentTime || 0) - 10);
        else if (c === 'fwd') m.currentTime = Math.min(isFinite(m.duration) ? m.duration : 1e9, (m.currentTime || 0) + 10);
        else if (c === 'mute') m.muted = !m.muted;
      } catch (e) { }
      tickMedia();
    }
    function note(msg) {
      if (!w || w.closed || !els.note) return;
      els.note.textContent = msg;
      clearTimeout(noteTimer);
      noteTimer = setTimeout(function () { if (els.note) els.note.textContent = ''; }, 9000);
    }

    function mkFrame(doc, name, url, a, key) {
      var f = doc.createElement('iframe');
      f.name = name;
      f.setAttribute('tabindex', '-1');
      f.setAttribute('aria-hidden', 'true');
      f.style.width = a.w + 'px'; f.style.height = a.h + 'px';
      f.dataset.key = key;
      if (key === 'cur' && !showCurLive) { f.src = 'about:blank'; ready.cur = false; return f; }
      if (window.__HDEK_SRCDOC__) f.srcdoc = window.__HDEK_SRCDOC__;
      else f.src = url;
      return f;
    }

    function onMsg(e) {
      var d = e.data;
      if (!d || d.hdek !== 1) return;
      if (d.type === 'ready') {
        var key = (e.source === (els.curframe && els.curframe.contentWindow)) ? 'cur' : (e.source === (els.nxtframe && els.nxtframe.contentWindow)) ? 'nxt' : null;
        if (!key) return;
        ready[key] = true;
        var q = queued[key] || {};
        ['zoom', 'goto', 'media'].forEach(function (ty) { if (q[ty]) post(key, q[ty]); });
      }
      if (d.type === 'key') {
        var fromPreview = e.source && ((els.curframe && e.source === els.curframe.contentWindow) || (els.nxtframe && e.source === els.nxtframe.contentWindow));
        if (!fromPreview || typeof d.key !== 'string') return; // anything embedded in a slide could post here
        handleKey({ key: d.key, shiftKey: !!d.shiftKey, target: null, preventDefault: function () { }, stopImmediatePropagation: function () { } });
      }
    }

    function post(key, msg) {
      var f = key === 'cur' ? els.curframe : els.nxtframe;
      (queued[key] = queued[key] || {})[msg.type] = msg; // the latest message of each kind, replayed when the frame is ready
      if (!f || !ready[key]) return;
      try { f.contentWindow.postMessage(msg, '*'); } catch (e) { }
    }

    function layout() {
      if (!w || w.closed) return;
      var a = aspect();
      [['cur', els.cur, els.curbox, els.curframe], ['nxt', els.nxt, els.nxtbox, els.nxtframe]].forEach(function (t) {
        var host = t[1], box = t[2], fr = t[3];
        if (!host || !box) return;
        var r = host.getBoundingClientRect(), cs = w.getComputedStyle(host);
        var aw = r.width - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), ah = r.height - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
        var s = Math.min(aw / a.w, ah / a.h);
        if (!(s > 0)) return;
        box.style.width = (a.w * s) + 'px'; box.style.height = (a.h * s) + 'px';
        if (fr) { fr.style.width = a.w + 'px'; fr.style.height = a.h + 'px'; fr.style.transform = 'scale(' + s + ')'; }
        if (t[0] === 'cur') placeInk(s);
      });
      pinkZoom(true);
      renderInk();
    }
    // The audience stores ink relative to the slide rectangle; in an unstaged deck that rectangle is only part of
    // the window, so the presenter canvas must cover the same part of the preview.
    function placeInk(s) {
      if (!els.pink) return;
      var st = els.pink.style;
      if (D.staged || D.mode === 'reveal') { st.left = '0'; st.top = '0'; st.width = '100%'; st.height = '100%'; return; }
      var r = inkBox();
      st.left = (r.left * s) + 'px'; st.top = (r.top * s) + 'px'; st.width = (r.width * s) + 'px'; st.height = (r.height * s) + 'px';
    }
    function placeInkNow() {
      if (!w || w.closed || !els.cur) return;
      var a = aspect(), r = els.curbox.getBoundingClientRect(), s = r.width / a.w;
      if (s > 0) placeInk(s);
    }

    function update() {
      if (!w || w.closed) return;
      var A = adapter(), st = D.state, n = A.count(), s = D.slides[st.slide];
      els.num.textContent = (st.slide + 1) + ' / ' + n;
      var mx = A.max(st.slide);
      els.stepn.textContent = mx ? (T('단계 ', 'Step ') + st.step + ' / ' + mx) : '';
      els.notes.innerHTML = (s && s.notesHTML) ? s.notesHTML : T('<span class="empty">이 슬라이드에는 노트가 없습니다.</span>', '<span class="empty">No notes for this slide.</span>');
      els.notes.classList.toggle('rich', !!(s && /<(p|ul|ol|li|br|div|h\d)\b/i.test(s.notesHTML)));
      els.notes.scrollTop = 0;
      els.blankst.textContent = D.blank ? (D.blank === 'white' ? T('● 흰 화면 표시 중', '● White screen on') : T('● 검은 화면 표시 중', '● Black screen on')) : '';
      // next state
      var nx = null;
      if (st.step < mx) nx = { slide: st.slide, step: st.step + 1 };
      else if (st.slide < n - 1) nx = { slide: st.slide + 1, step: 0 };
      if (nx) {
        els.endcard.style.display = 'none';
        post('nxt', { hdek: 1, type: 'goto', slide: nx.slide, step: nx.step, animate: false });
        var lbl = w.document.getElementById('nxtlabel');
        lbl.textContent = nx.slide === st.slide ? T('다음: 같은 슬라이드의 단계 ', 'Next: same slide, step ') + nx.step : T('다음 슬라이드 ', 'Next slide ') + (nx.slide + 1) + (D.slides[nx.slide] ? ' · ' + D.slides[nx.slide].title : '');
      } else {
        els.endcard.style.display = 'grid';
        w.document.getElementById('nxtlabel').textContent = T('마지막입니다', 'End of deck');
      }
      post('cur', { hdek: 1, type: 'goto', slide: st.slide, step: st.step, animate: true });
      els.resume.style.display = resumeOffer ? '' : 'none';
      if (resumeOffer) els.resume.textContent = T('↻ ' + (resumeOffer.slide + 1) + '번 슬라이드부터 이어서 (R)', '↻ Continue from slide ' + (resumeOffer.slide + 1) + ' (R)');
      if (st.slide !== mediaSlide) renderMedia();
      var hint = (document.fullscreenElement || document.webkitFullscreenElement) ? '' : T('청중 창에서 F → 프로젝터 전체화면', 'Press F in the audience window → projector fullscreen');
      els.hint.textContent = hint;
    }

    function onClick(e) {
      var t = e.target;
      if (!t.closest || t.closest('.hdg')) return; // the overview handles its own clicks
      var mb = t.closest('button[data-m]');
      if (mb) { mediaCmd(+mb.closest('.mrow').dataset.i, mb.dataset.m); try { mb.blur(); } catch (x) { } return; }
      if (t.closest('#media')) return;
      var b = t.closest('button[data-act]');
      if (b) {
        var a = b.dataset.act;
        try { b.blur(); } catch (x) { }
        if (a === 'reset') { timer = { start: 0, acc: 0, running: false }; startTimer(); return; }
        if (a === 'curlive') { showCurLive = !showCurLive; store('hdek-cur-live', showCurLive ? 'on' : 'off'); build(); return; }
        if (a === 'full') {
          // A click in the presenter window is not user activation for the audience window, so hand focus over
          try { window.focus(); } catch (x) { }
          toggleFullscreen();
          return;
        }
        if (a === 'color') { D.color = b.dataset.color; if (!D.tool || D.tool === 'laser' || D.tool === 'eraser') setTool('pen'); else toolChanged(); updateBar(); return; }
        action(a);
        return;
      }
      // Clicking either slide preview advances, as in PowerPoint's presenter view (not while a pen tool is on)
      if (!D.tool && e.button === 0 && Date.now() >= inkClickBlock && t.closest && t.closest('#curbox, #nxtbox')) next();
    }

    // Wheel over the slide previews moves back and forth; the notes keep scrolling normally
    function onWheel(e) {
      var t = e.target;
      if (!t.closest || t.closest('#media, .hdg') || !t.closest('#cur, #nxt') || e.ctrlKey) return;
      if (D.tool === 'zoom' && t.closest('#curbox')) { zoomWheel(e, previewPoint(e.clientX, e.clientY)); return; }
      e.preventDefault();
      var now = Date.now();
      if (now < wheelLock) { wheelLock = Math.max(wheelLock, now + 180); return; }
      wheelAcc += e.deltaY;
      if (Math.abs(wheelAcc) < 30) return;
      if (wheelAcc > 0) next(); else prev();
      wheelAcc = 0; wheelLock = now + 450;
    }

    function setNotes(d) {
      notesSize = clamp(notesSize + d, 12, 60);
      store('hdek-notes-size', String(notesSize));
      if (els.notes) els.notes.style.fontSize = notesSize + 'px';
    }

    function startTimer() { timer.start = Date.now(); timer.running = true; tickTimer(); }
    function toggleTimer() {
      if (timer.running) { timer.acc += Date.now() - timer.start; timer.running = false; }
      else { timer.start = Date.now(); timer.running = true; }
      tickTimer();
    }
    function tickTimer() {
      if (!w || w.closed) return;
      var ms = timer.acc + (timer.running ? Date.now() - timer.start : 0), sec = ms / 1000;
      els.elapsed.textContent = fmtTime(sec) + (timer.running ? '' : ' ⏸');
      var d = new Date();
      els.clock.textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      if (D.duration > 0) {
        var total = D.duration * 60, left = total - sec, ratio = clamp(sec / total, 0, 1);
        els.remain.textContent = (left >= 0 ? T('남은 시간 ', 'Remaining ') + fmtTime(left) : T('초과 ', 'Over ') + fmtTime(-left));
        els.prog.style.width = (ratio * 100) + '%';
        els.prog.className = left < 0 ? 'over' : (left < 60 ? 'warn' : (ratio > 0.75 ? 'mid' : ''));
        els.remain.className = left < 0 ? 'over' : (left < 60 ? 'warn' : '');
      } else { els.remain.textContent = ''; els.prog.style.width = '0'; }
    }

    function renderInkP(strokes, extra, lp, trail) {
      if (!w || w.closed || !inkP) return;
      inkP.render(strokes, extra, lp, trail);
    }

    function toolChanged() {
      if (!w || w.closed) return;
      if (els.pink) { els.pink.classList.toggle('active', !!D.tool); els.pink.classList.toggle('zoomtool', D.tool === 'zoom'); }
      $$('button[data-tool]', w.document).forEach(function (b) { b.classList.toggle('on', b.dataset.tool === D.tool); });
      $$('button[data-color]', w.document).forEach(function (b) { b.classList.toggle('on', b.dataset.color === D.color); });
    }

    function showGotoP(buf) {
      if (!w || w.closed || !els.goto) return;
      els.goto.style.display = buf ? 'block' : 'none';
      els.goto.textContent = buf ? buf + T(' 번 슬라이드로 → Enter', ' → Enter to go to slide') : '';
    }

    return {
      open: open, close: close, update: update, renderInk: renderInkP, toolChanged: toolChanged, showGoto: showGotoP,
      isOpen: function () { return !!(w && !w.closed); }, layout: layout, placeInk: placeInkNow,
      zoom: zoomP, note: note, grid: function () { return (w && !w.closed) ? pgrid : null; }
    };
  })();

  function escapeHTML(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  var PRESENTER_CSS = [
    ':root{color-scheme:dark}',
    '*{box-sizing:border-box}',
    'html,body{margin:0;height:100%;background:#0e0e11;color:#ececf0;font:15px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI","Apple SD Gothic Neo","Malgun Gothic","Noto Sans KR",sans-serif;overflow:hidden}',
    '#app{display:grid;grid-template-rows:auto 1fr auto;height:100%}',
    '#top{display:flex;align-items:center;gap:18px;padding:10px 16px;border-bottom:1px solid #222228;background:#141418}',
    '#top>*{flex:none;white-space:nowrap}',
    '#top>#title,#top>#hint,#top>#note{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}',
    '#top>.sp{flex:1 1 0}',
    '#title{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:32vw;color:#b8b8c2}',
    '#num{font-size:20px;font-weight:700;font-variant-numeric:tabular-nums}',
    '#stepn{color:#8f8f9a;font-variant-numeric:tabular-nums}',
    '.sp{flex:1}',
    '#elapsed{font-size:26px;font-weight:700;font-variant-numeric:tabular-nums;cursor:pointer;user-select:none}',
    '#remain{color:#9fa0aa;font-variant-numeric:tabular-nums;min-width:120px;text-align:right}',
    '#remain.warn{color:#ffb340}#remain.over{color:#ff5a52;font-weight:700}',
    '#clock{color:#8f8f9a;font-variant-numeric:tabular-nums}',
    '.durw{color:#8f8f9a;font-size:13px}.durw input{width:52px;background:#1e1e24;color:#fff;border:1px solid #33333b;border-radius:6px;padding:3px 6px;font:inherit}',
    '#pbar{height:4px;background:#1c1c22}#prog{height:100%;width:0;background:#30d158;transition:width .5s}#prog.mid{background:#ffd60a}#prog.warn{background:#ff9f0a}#prog.over{background:#ff453a}',
    '#main{display:grid;grid-template-columns:minmax(0,1.85fr) minmax(300px,1fr);gap:14px;padding:14px;min-height:0}',
    '.pane{position:relative;min-height:0;display:grid;place-items:center}',
    '#cur{background:#08080a;border-radius:10px}',
    '.box{position:relative;overflow:hidden;background:#000;border-radius:6px;box-shadow:0 0 0 1px #2a2a31}',
    '#curbox{box-shadow:0 0 0 2px #0a84ff55;cursor:pointer}',
    '#nxtbox{cursor:pointer}',
    '.box iframe{position:absolute;left:0;top:0;border:0;transform-origin:0 0;pointer-events:none;background:#000}',
    '.pink{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;touch-action:none}',
    '.pink.active{pointer-events:auto;cursor:crosshair}',
    '#curoff{position:absolute;inset:0;display:none;place-items:center;color:#777;font-size:14px;text-align:center;padding:20px}',
    '#side{display:grid;grid-template-rows:minmax(0,0.9fr) auto minmax(0,1.4fr);gap:8px;min-height:0}',
    '#nxt{background:#08080a;border-radius:10px}',
    '#nxtlabel{color:#9a9aa5;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '#endcard{position:absolute;inset:0;display:none;place-items:center;color:#777;background:#0b0b0e}',
    '#notesw{position:relative;min-height:0;display:flex;flex-direction:column;background:#141418;border-radius:10px;border:1px solid #222228}',
    '#notesh{display:flex;align-items:center;gap:6px;padding:6px 10px;border-bottom:1px solid #222228;color:#8f8f9a;font-size:13px}',
    '#notesh button{all:unset;cursor:pointer;padding:2px 9px;border-radius:6px;background:#22222a;color:#ddd;font-weight:700}',
    '#notes{flex:1;overflow:auto;padding:14px 18px;white-space:pre-wrap;line-height:1.55}',
    '#notes p{margin:0 0 .6em}#notes ul,#notes ol{margin:0 0 .6em;padding-left:1.3em}',
    '#notes .empty{color:#666}',
    '#notes.rich{white-space:normal}',
    '#bar button[data-act="color"]{min-width:30px;padding:0 6px}',
    '#bar{display:flex;align-items:center;gap:5px;padding:8px 12px;border-top:1px solid #222228;background:#141418;flex-wrap:wrap}',
    '#bar button{all:unset;cursor:pointer;height:36px;min-width:36px;padding:0 8px;border-radius:8px;background:#202027;color:#e5e5ea;display:inline-flex;align-items:center;justify-content:center;gap:6px;font-size:14px}',
    '#bar button:hover{background:#2a2a33}',
    '#bar button.big{min-width:84px;font-weight:700;background:#2b2b35}',
    '#bar button.on{background:#0a84ff;color:#fff}',
    '#bar svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}',
    '#bar .sw{width:16px;height:16px;border-radius:50%;border:2px solid rgba(255,255,255,.5)}',
    '#bar .sep{width:1px;height:24px;background:#2c2c34;margin:0 4px}',
    '#hint,#note{color:#ffb340;font-size:13px}',
    '#note{max-width:38vw}',
    '#blankst{color:#ff6961;font-weight:700}',
    '#resume{all:unset;cursor:pointer;padding:5px 11px;border-radius:7px;background:#0a84ff;color:#fff;font-size:13px;font-weight:600;white-space:nowrap}',
    '.pink.zoomtool{cursor:zoom-in}',
    '.zband{position:absolute;display:none;border:2px solid #0a84ff;background:rgba(10,132,255,.15);border-radius:3px;pointer-events:none;z-index:3}',
    '#cur.hasmedia{padding-bottom:calc(var(--mrows) * 44px + 8px)}',
    '#media{position:absolute;left:8px;right:8px;bottom:6px;display:flex;flex-direction:column;gap:4px}',
    '#media:empty{display:none}',
    '.mrow{display:flex;align-items:center;gap:6px;height:40px;padding:0 8px;background:#18181e;border:1px solid #2a2a32;border-radius:9px}',
    '.mrow button{all:unset;cursor:pointer;height:30px;min-width:30px;padding:0 7px;box-sizing:border-box;border-radius:7px;display:inline-flex;align-items:center;justify-content:center;background:#25252d;color:#e5e5ea;font-size:12px;font-variant-numeric:tabular-nums}',
    '.mrow button:hover{background:#31313b}',
    '.mrow button.on{background:#0a84ff;color:#fff}',
    '.mrow svg{width:16px;height:16px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}',
    '.mrow input{flex:1;min-width:60px;accent-color:#0a84ff;cursor:pointer}',
    '.mrow .mt{color:#b5b5be;font-size:12px;font-variant-numeric:tabular-nums;min-width:96px;text-align:center}',
    '.mrow .mi{color:#8a8a94;font-size:12px;min-width:22px}',
    '#goto{position:fixed;right:20px;bottom:70px;padding:8px 14px;border-radius:10px;background:#0a84ff;color:#fff;font-size:18px;display:none}'
  ].join('\n');

  var PRESENTER_HTML = '' +
    '<div id="app">' +
    '<div><div id="top"><span id="title"></span><span id="num"></span><span id="stepn"></span><span id="blankst"></span><button id="resume" data-act="resume" style="display:none"></button><span id="note"></span><span class="sp"></span>' +
    T('<span id="hint"></span><span class="durw">목표 <input id="dur" type="number" min="0" step="1" placeholder="분">분</span>', '<span id="hint"></span><span class="durw">Target <input id="dur" type="number" min="0" step="1" placeholder="min">min</span>') +
    T('<span id="remain"></span><span id="elapsed" title="클릭: 일시정지/재개">0:00</span><span id="clock"></span></div>', '<span id="remain"></span><span id="elapsed" title="Click: pause/resume">0:00</span><span id="clock"></span></div>') +
    '<div id="pbar"><div id="prog"></div></div></div>' +
    '<div id="main">' +
    T('<div id="cur" class="pane"><div id="curbox" class="box"><div id="curoff">현재 화면 미리보기가 꺼져 있습니다<br>(무거운 덱에서 성능을 아끼는 모드) — 필기는 그대로 됩니다</div><div id="zband" class="zband"></div></div><div id="media"></div></div>', '<div id="cur" class="pane"><div id="curbox" class="box"><div id="curoff">Live preview of the current slide is off<br>(saves performance on heavy decks) — drawing still works</div><div id="zband" class="zband"></div></div><div id="media"></div></div>') +
    '<div id="side">' +
    T('<div id="nxt" class="pane"><div id="nxtbox" class="box"><div id="endcard">마지막 슬라이드입니다</div></div></div>', '<div id="nxt" class="pane"><div id="nxtbox" class="box"><div id="endcard">This is the last slide</div></div></div>') +
    '<div id="nxtlabel"></div>' +
    T('<div id="notesw"><div id="notesh">발표자 노트<span class="sp"></span><button id="notesminus">A−</button><button id="notesplus">A+</button></div><div id="notes"></div></div>', '<div id="notesw"><div id="notesh">Speaker notes<span class="sp"></span><button id="notesminus">A−</button><button id="notesplus">A+</button></div><div id="notes"></div></div>') +
    '</div></div>' +
    '<div id="bar">' +
    '<button class="big" data-act="prev">' + svg('prev') + T('이전</button><button class="big" data-act="next">다음', 'Prev</button><button class="big" data-act="next">Next') + svg('next') + '</button>' +
    '<span class="sep"></span>' +
    T('<button data-act="pen" data-tool="pen" title="펜 (D)">', '<button data-act="pen" data-tool="pen" title="Pen (D)">') + svg('pen') + '</button>' +
    T('<button data-act="hl" data-tool="hl" title="형광펜 (H)">', '<button data-act="hl" data-tool="hl" title="Highlighter (H)">') + svg('hl') + '</button>' +
    T('<button data-act="laser" data-tool="laser" title="레이저 (L)">', '<button data-act="laser" data-tool="laser" title="Laser (L)">') + svg('laser') + '</button>' +
    T('<button data-act="eraser" data-tool="eraser" title="지우개 (E)">', '<button data-act="eraser" data-tool="eraser" title="Eraser (E)">') + svg('eraser') + '</button>' +
    T('<button data-act="zoom" data-tool="zoom" title="돋보기 (Z): 현재 화면에서 클릭은 2배, 드래그는 그 영역, 오른쪽 클릭은 축소">', '<button data-act="zoom" data-tool="zoom" title="Magnifier (Z): on the current slide click = 2×, drag = that area, right-click = zoom out">') + svg('zoom') + '</button>' +
    COLORS.slice(0, 4).map(function (c) { return '<button data-act="color" data-color="' + c + T('" title="색"><span class="sw" style="background:', '" title="Color"><span class="sw" style="background:') + c + '"></span></button>'; }).join('') +
    T('<button data-act="clear" title="이 슬라이드 필기 지우기 (C)">', '<button data-act="clear" title="Clear ink on this slide (C)">') + svg('clear') + '</button>' +
    '<span class="sep"></span>' +
    T('<button data-act="blank" title="검은 화면 (B)">', '<button data-act="blank" title="Black screen (B)">') + svg('blank') + '</button>' +
    T('<button data-act="grid" title="슬라이드 한눈에 보기 · 검색 (G)">', '<button data-act="grid" title="All slides · search (G)">') + svg('grid') + T('슬라이드</button>', 'Slides</button>') +
    T('<button data-act="full" title="청중 화면 전체화면 (F)">', '<button data-act="full" title="Audience fullscreen (F)">') + svg('full') + '</button>' +
    T('<button data-act="curlive" title="현재 화면 실시간 미리보기 켜기/끄기">미리보기</button>', '<button data-act="curlive" title="Toggle live preview of the current slide">Preview</button>') +
    T('<button data-act="reset" title="타이머 재시작">타이머 ↺</button>', '<button data-act="reset" title="Restart timer">Timer ↺</button>') +
    T('<button data-act="print" title="모든 단계를 펼쳐 인쇄/PDF 저장">PDF</button>', '<button data-act="print" title="Print / save PDF with every step revealed">PDF</button>') +
    '</div>' +
    '<div id="goto"></div>' +
    '</div>';

  // ------------------------------------------------------------------ preview role
  function setupPreview() {
    document.documentElement.classList.add('hdek-preview');
    var muteAll = function () { $$('video, audio').forEach(function (m) { m.muted = true; m.volume = 0; }); };
    muteAll();
    try { new MutationObserver(muteAll).observe(document.documentElement, { childList: true, subtree: true }); } catch (e) { }
    // only the current-slide preview plays video (following the projector); the next-slide preview and thumbnails stay still
    if (window.name !== 'hdek-preview-cur') document.addEventListener('play', function (e) { try { e.target.pause(); } catch (x) { } }, true);
    window.addEventListener('message', function (e) {
      var d = e.data;
      if (!d || d.hdek !== 1) return;
      // the presenter page is driven by the audience window's script, so messages come from the parent or its opener
      var ok = e.source === window.parent;
      try { ok = ok || (!!window.parent.opener && e.source === window.parent.opener); } catch (x) { }
      if (!ok) return;
      if (d.type === 'goto') go(+d.slide || 0, +d.step || 0, !!d.animate);
      if (d.type === 'zoom') {
        var r = d.r;
        zoomRect = (r && isFinite(r.x) && isFinite(r.y) && r.w > 0 && r.h > 0) ? { x: +r.x, y: +r.y, w: +r.w, h: +r.h } : null;
        applyZoom(!!d.instant);
      }
      if (d.type === 'media' && Array.isArray(d.list) && +d.slide === D.state.slide) {
        var ms = currentMedia();
        d.list.forEach(function (x, i) {
          var m = ms[i];
          if (!m || !x || !isFinite(x.t)) return;
          try {
            m.muted = true;
            if (Math.abs((m.currentTime || 0) - x.t) > (x.p ? 0.6 : 0.05)) m.currentTime = x.t;
            if (x.p && m.paused) { var p = m.play(); if (p && p.catch) p.catch(function () { }); }
            else if (!x.p && !m.paused) m.pause();
          } catch (e2) { }
        });
      }
    });
    window.addEventListener('keydown', function (e) {
      if (e.__hdek || !e.isTrusted) return; // never echo our own synthetic keys back
      try { window.parent.postMessage({ hdek: 1, type: 'key', key: e.key, shiftKey: e.shiftKey }, '*'); } catch (x) { }
    });
    window.addEventListener('resize', function () { fit(); if (zoomRect) applyZoom(true); });
    try { window.parent.postMessage({ hdek: 1, type: 'ready', count: adapter().count() }, '*'); } catch (e) { }
  }

  // ------------------------------------------------------------------ shared helpers: size, media
  function slideAspect() {
    if (D.mode === 'reveal') { var c = window.Reveal.getConfig(); return { w: c.width || 960, h: c.height || 700 }; }
    if (D.staged) return { w: D.width, h: D.height };
    return { w: window.innerWidth || 1280, h: window.innerHeight || 720 };
  }
  function deckURL() {
    if (window.__HDEK_SRC__) return window.__HDEK_SRC__;
    return location.href.replace(/#.*$/, '');
  }
  // video and audio on the current slide (in the order they appear)
  function currentMedia() {
    var s = D.slides[D.state.slide];
    if (!s || !s.el) return [];
    return $$('video, audio', s.el).filter(function (m) { return !!(m.currentSrc || m.src || m.querySelector('source')); });
  }
  function togglePlay(m) {
    if (!m) return;
    if (!m.paused && !m.ended) { m.pause(); return; }
    var fail = function (err) {
      if (!err || err.name !== 'NotAllowedError' || m.muted) return;
      // the browser blocks sound until the audience window has been used once: play silently and say so
      m.muted = true;
      try { var p2 = m.play(); if (p2 && p2.catch) p2.catch(function () { }); } catch (x) { }
      var msg = T('브라우저가 소리를 막아 소리 없이 재생합니다. 청중 창에서 아무 키나 한 번 누른 뒤 🔊 를 누르세요', 'The browser blocked sound, so the video plays muted. Press any key once in the audience window, then press 🔊');
      Presenter.note(msg); toast(msg, 5000);
    };
    try { var p = m.play(); if (p && p.catch) p.catch(fail); } catch (e) { fail(e); }
  }

  // ------------------------------------------------------------------ slide overview: thumbnails + search
  var audGrid = null;
  var BLOCK_RE = /^(P|DIV|LI|UL|OL|H[1-6]|SECTION|ARTICLE|ASIDE|HEADER|FOOTER|FIGURE|FIGCAPTION|TABLE|THEAD|TBODY|TR|TD|TH|BLOCKQUOTE|PRE|DT|DD|DL|MAIN|NAV|LABEL|BUTTON|SVG|TEXT)$/i;
  // the slide's visible text for search: words in different blocks stay apart, notes/scripts/styles are left out
  function searchText(el) {
    var out = '', last = null, skip = 'script, style, template, noscript, ' + NOTES_SEL;
    var tw = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (var n = tw.nextNode(); n; n = tw.nextNode()) {
      if (n.nodeType === 1) { if (n.tagName === 'BR') out += ' '; continue; }
      var p = n.parentElement;
      if (!p || p.closest(skip)) continue;
      var b = p; while (b && b !== el && !BLOCK_RE.test(b.tagName)) b = b.parentElement;
      if (b !== last) { out += ' '; last = b; }
      out += n.nodeValue;
    }
    return out.replace(/\s+/g, ' ').trim();
  }
  function SlideGrid(doc, mount, win) {
    var root = null, list = null, q = null, nEl = null, cards = [], frames = [], waiting = [], loading = 0, sel = -1, io = null, hay = null, a = null;
    function haystack() {
      if (hay) return hay;
      var norm = function (s) { return (s.normalize ? s.normalize('NFC') : s); };
      hay = D.slides.map(function (s) {
        var notes = '', body = '';
        try { notes = textOf(new DOMParser().parseFromString(s.notesHTML || '', 'text/html').body); } catch (e) { }
        try { body = searchText(s.el); } catch (e) { body = textOf(s.el); }
        if (body.indexOf(s.title) === 0) body = body.slice(s.title.length).trim(); // the heading is already the card's caption
        var text = norm((s.title + ' · ' + body + (notes ? ' · ' + notes : '')).replace(/\s+/g, ' '));
        return { text: text, low: text.toLowerCase(), skip: s.title.length + 3 };
      });
      return hay;
    }
    function open() {
      if (root) return;
      a = slideAspect();
      root = doc.createElement('div'); root.className = 'hdg';
      root.innerHTML = '<div class="hdg-top"><input class="hdg-q" type="search" autocomplete="off" spellcheck="false" placeholder="' +
        T('찾을 말 (제목 · 본문 · 노트) 또는 슬라이드 번호', 'Search titles, text and notes, or type a slide number') + '"><span class="hdg-n"></span><span class="hdg-sp"></span>' +
        '<button class="hdg-x">' + T('닫기 (Esc)', 'Close (Esc)') + '</button></div><div class="hdg-cards"></div>';
      mount.appendChild(root);
      q = root.querySelector('.hdg-q'); list = root.querySelector('.hdg-cards'); nEl = root.querySelector('.hdg-n');
      cards = D.slides.map(function (s, i) {
        var c = doc.createElement('div');
        c.className = 'hdg-card' + (i === D.state.slide ? ' now' : '');
        c.dataset.i = String(i);
        c.innerHTML = '<div class="hdg-th" style="aspect-ratio:' + a.w + ' / ' + a.h + '"><div class="hdg-ph">' + escapeHTML(s.title) + '</div></div>' +
          '<div class="hdg-cap"><b>' + (i + 1) + '</b><span>' + escapeHTML(s.title) + '</span></div><div class="hdg-snip"></div>';
        list.appendChild(c);
        return c;
      });
      list.addEventListener('click', function (e) { var c = e.target.closest && e.target.closest('.hdg-card'); if (c) pick(+c.dataset.i); });
      root.querySelector('.hdg-x').addEventListener('click', close);
      q.addEventListener('input', filter);
      win.addEventListener('message', onMsg);
      win.addEventListener('resize', scale);
      // thumbnails load only when they scroll into view, a few at a time
      try {
        io = new win.IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) want(+en.target.dataset.i); }); }, { root: list, rootMargin: '300px 0px' });
        cards.forEach(function (c) { io.observe(c); });
      } catch (e) { io = null; }
      filter();
      select(D.state.slide);
      scale();
      try { cards[D.state.slide].scrollIntoView({ block: 'center' }); } catch (e) { }
      setTimeout(function () { try { q.focus(); } catch (e) { } }, 0);
    }
    function close() {
      if (!root) return;
      if (io) io.disconnect();
      frames.forEach(function (f) { if (f) clearTimeout(f.timer); });
      try { root.remove(); } catch (e) { }
      root = null; frames = []; waiting = []; loading = 0; cards = []; sel = -1; io = null;
      win.removeEventListener('message', onMsg);
      win.removeEventListener('resize', scale);
    }
    function scale() {
      if (!root) return;
      var th = null;
      for (var i = 0; i < cards.length && !th; i++) if (!cards[i].hidden) th = cards[i].firstChild;
      if (th && th.clientWidth) list.style.setProperty('--hdg-s', String(th.clientWidth / a.w));
    }
    function want(i) {
      if (frames[i] || waiting.indexOf(i) >= 0) return;
      waiting.push(i); pump();
    }
    function pump() {
      while (root && loading < 3 && waiting.length) {
        var i = waiting.shift();
        if (frames[i] || !cards[i] || cards[i].hidden) continue;
        var f = doc.createElement('iframe');
        f.name = 'hdek-preview-thumb';
        f.setAttribute('tabindex', '-1'); f.setAttribute('aria-hidden', 'true');
        f.style.width = a.w + 'px'; f.style.height = a.h + 'px'; f.style.transform = 'scale(var(--hdg-s, .1))';
        if (window.__HDEK_SRCDOC__) f.srcdoc = window.__HDEK_SRCDOC__; else f.src = deckURL();
        var rec = frames[i] = { f: f, done: false };
        rec.timer = setTimeout(done.bind(null, i), 8000);
        loading++;
        cards[i].firstChild.appendChild(f);
      }
    }
    function done(i) {
      var r = frames[i];
      if (!r || r.done) return;
      r.done = true; clearTimeout(r.timer); loading = Math.max(0, loading - 1);
      pump();
    }
    function onMsg(e) {
      var d = e.data;
      if (!d || d.hdek !== 1 || d.type !== 'ready') return;
      for (var i = 0; i < frames.length; i++) {
        var r = frames[i];
        if (r && r.f.contentWindow === e.source) {
          // each thumbnail shows the slide with every step revealed, as it will look after a jump
          try { r.f.contentWindow.postMessage({ hdek: 1, type: 'goto', slide: i, step: adapter().max(i), animate: false }, '*'); } catch (x) { }
          (function (f) { setTimeout(function () { f.classList.add('on'); }, 250); })(r.f);
          done(i);
          return;
        }
      }
    }
    function snippet(h, toks) {
      var at = -1;
      toks.forEach(function (t) { var p = h.low.indexOf(t, h.skip); if (p >= 0 && (at < 0 || p < at)) at = p; });
      if (at < 0) return '';
      var from = Math.max(h.skip, at - 28), to = Math.min(h.text.length, at + 72);
      if (from > h.skip) { var sp = h.text.indexOf(' ', from); if (sp >= 0 && sp < at) from = sp + 1; } // start on a word
      var part = (from > h.skip ? '…' : '') + h.text.slice(from, to) + (to < h.text.length ? '…' : '');
      var re = new RegExp('(' + toks.map(function (t) { return t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')', 'gi');
      return part.split(re).map(function (x, k) { return k % 2 ? '<mark>' + escapeHTML(x) + '</mark>' : escapeHTML(x); }).join('');
    }
    function filter() {
      if (!root) return;
      var raw = q.value || '';
      if (raw.normalize) raw = raw.normalize('NFC');
      var toks = raw.toLowerCase().split(/\s+/).filter(Boolean), H = toks.length ? haystack() : null, shown = 0, first = -1;
      var num = toks.length === 1 && /^\d+$/.test(toks[0]) ? +toks[0] - 1 : -1;
      cards.forEach(function (c, i) {
        var ok = !toks.length || i === num || toks.every(function (t) { return H[i].low.indexOf(t) >= 0; });
        c.hidden = !ok;
        c.lastChild.innerHTML = ok && toks.length ? snippet(H[i], toks) : '';
        if (ok) { shown++; if (first < 0) first = i; }
      });
      var none = list.querySelector('.hdg-none');
      if (!shown && !none) { none = doc.createElement('div'); none.className = 'hdg-none'; none.textContent = T('찾는 말이 있는 슬라이드가 없습니다', 'No slide matches'); list.appendChild(none); }
      if (shown && none) none.remove();
      nEl.textContent = toks.length ? T(shown + '장 찾음', shown + ' found') : T(cards.length + '장', cards.length + ' slides');
      if (toks.length) select(num >= 0 && cards[num] ? num : first);
      scale();
      if (!io) return;
      // cards revealed by the filter: load the ones on screen
      cards.forEach(function (c, i) { if (!c.hidden && !frames[i]) { var r = c.getBoundingClientRect(), lr = list.getBoundingClientRect(); if (r.bottom > lr.top - 300 && r.top < lr.bottom + 300) want(i); } });
    }
    function select(i) {
      if (sel >= 0 && cards[sel]) cards[sel].classList.remove('sel');
      sel = i;
      if (i >= 0 && cards[i]) { cards[i].classList.add('sel'); try { cards[i].scrollIntoView({ block: 'nearest' }); } catch (e) { } }
    }
    function visible() { var v = []; cards.forEach(function (c, i) { if (!c.hidden) v.push(i); }); return v; }
    function cols() { try { return Math.max(1, win.getComputedStyle(list).gridTemplateColumns.split(' ').filter(Boolean).length); } catch (e) { return 1; } }
    function move(d) {
      var v = visible(); if (!v.length) return;
      var p = v.indexOf(sel);
      select(v[clamp(p < 0 ? 0 : p + d, 0, v.length - 1)]);
    }
    function pick(i) {
      close();
      // jump to the slide as the thumbnail showed it: every step revealed
      go(i, adapter().max(i), false);
    }
    function key(e) {
      var k = e.key, stop = true;
      if (k === 'Escape') close();
      else if (k === 'Enter') { var v = visible(); if (sel >= 0 && v.indexOf(sel) >= 0) pick(sel); else if (v.length) pick(v[0]); }
      else if (k === 'ArrowRight' || k === 'PageDown') move(1);
      else if (k === 'ArrowLeft' || k === 'PageUp') move(-1);
      else if (k === 'ArrowDown') move(cols());
      else if (k === 'ArrowUp') move(-cols());
      else {
        stop = false;
        // typing goes to the search box
        try { if (q && q.getRootNode().activeElement !== q && !e.ctrlKey && !e.metaKey && !e.altKey) q.focus(); } catch (x) { }
      }
      if (stop) { e.preventDefault(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); }
    }
    return { open: open, close: close, key: key, isOpen: function () { return !!root; } };
  }

  // ------------------------------------------------------------------ init
  function start() {
    if (D.ready) return;
    var html = document.documentElement;
    injectCSS(document, CSS, 'hdek-runtime-css');
    if (window.Reveal && document.querySelector('.reveal .slides')) {
      var R = window.Reveal;
      var boot = function () {
        RevealAdapter.transition = (R.getConfig && R.getConfig().transition) || 'slide';
        if (ROLE === 'preview') R.configure({ transition: 'none', controls: false, progress: false, keyboard: false, slideNumber: false });
        D.adapter = RevealAdapter;
        RevealAdapter.init();
        finishInit();
      };
      if (R.isReady && R.isReady()) boot(); else if (R.on) R.on('ready', boot); else boot();
      return;
    }
    detect();
    html.classList.add('hdek-on');
    if (D.mode === 'driver') {
      // The deck's own engine owns the screen; we only read its state and steer with keys.
      html.classList.add('hdek-own');
      D.state = Driver.read();
      D.slides.forEach(function (x, i) { x.el.classList.toggle('hdek-current', i === D.state.slide); });
      finishInit();
      return;
    }
    if (D.staged) { html.classList.add('hdek-staged'); D.root.classList.add('hdek-stage'); }
    if (D.autostage) {
      html.classList.add('hdek-autostage');
      var bd = document.createElement('div'); bd.className = 'hdek-backdrop'; document.body.appendChild(bd);
    }
    // every slide to step 0
    D.slides.forEach(function (s) { setSteps(s, 0, false); });
    var startAt = (ROLE === 'audience' && parseHash()) || { slide: 0, step: 0 };
    startAt.slide = clamp(startAt.slide, 0, D.slides.length - 1);
    startAt.step = clamp(startAt.step, 0, D.slides[startAt.slide].max);
    D.state = { slide: -1, step: 0 };
    Native.apply({ slide: -1, step: 0 }, startAt, false);
    D.state = startAt;
    fit();
    finishInit();
  }

  // "Continue where you stopped": the position is saved on every move; reopening the deck offers it (R) instead of jumping there
  var resumeOffer = null;
  function savedPos() {
    try {
      var p = JSON.parse(store('hdek-pos:' + deckKey()) || 'null');
      return p && typeof p.slide === 'number' && p.slide >= 0 ? { slide: p.slide | 0, step: (p.step | 0) || 0, t: p.t || 0 } : null;
    } catch (e) { return null; }
  }
  function offerResume(last) {
    var n = adapter().count();
    if (!last || D.state.slide !== 0 || D.state.step !== 0 || last.slide <= 0 || last.slide >= n - 1) return;
    resumeOffer = { slide: last.slide, step: Math.min(last.step, adapter().max(last.slide)), from: D.state.slide };
    store('hdek-pos:' + deckKey(), JSON.stringify(last)); // keep it until the talk actually moves
    toast(T('지난번 ' + (last.slide + 1) + '번 슬라이드에서 멈췄습니다 · R 을 누르면 거기서 이어서 시작합니다', 'You stopped at slide ' + (last.slide + 1) + ' last time · press R to continue there'), 7000);
  }

  function finishInit() {
    D.ready = true;
    if (ROLE === 'preview') { setupPreview(); return; }
    var last = savedPos();
    setupUI();
    setupInk();
    bindInput();
    loadScreens(false);
    fit();
    afterChange(true);
    offerResume(last);
    document.documentElement.setAttribute('data-hdek-mode', D.mode);
    console.info('[' + PRODUCT + ' ' + VERSION + '] mode=' + D.mode + ' slides=' + adapter().count() + (D.staged ? ' stage=' + D.width + 'x' + D.height : ''));
  }

  // ------------------------------------------------------------------ public API
  api.__runtime = true;
  api.version = VERSION;
  api.next = function () { next(); };
  api.prev = function () { prev(); };
  api.goto = function (slide, step, animate) { go(slide, step || 0, animate); };
  api.state = function () { return { slide: D.state.slide, step: D.state.step, count: adapter().count(), max: adapter().max(D.state.slide), mode: D.mode, role: ROLE }; };
  api.slides = function () { return D.slides.map(function (s) { return { id: s.id, title: s.title, steps: s.max, notes: s.notesHTML }; }); };
  api.onChange = function (fn) { D.listeners.push(fn); };
  api.register = function (idOrEl, hook) {
    var id = typeof idOrEl === 'string' ? idOrEl : (idOrEl && (idOrEl.getAttribute('data-slide') || idOrEl.id));
    pendingHooks[id] = hook;
    var s = D.slides.filter(function (x) { return x.id === id || x.el === idOrEl; })[0];
    if (s) {
      attachHook(s, hook);
      if (D.ready) {
        var i = D.slides.indexOf(s);
        setSteps(s, i === D.state.slide ? D.state.step : 0, false);
        if (Presenter.isOpen()) Presenter.update();
      }
    }
  };
  api.presenter = function () { Presenter.open(); };
  api.tool = function (t) { setTool(t || null); };
  api.ink = function () { return JSON.parse(JSON.stringify(D.ink)); };
  api.__debug = D;

  // Contract decks start right away; others start after the deck's own load handlers (auto-fit etc.)
  function afterLoad(fn) {
    var run = function () { requestAnimationFrame(function () { requestAnimationFrame(function () { setTimeout(fn, 30); }); }); };
    if (document.readyState === 'complete') run(); else window.addEventListener('load', run);
  }
  function boot() {
    if (document.querySelector('[data-hdek], [data-slide]') || (window.Reveal && document.querySelector('.reveal .slides'))) start();
    else afterLoad(start);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
